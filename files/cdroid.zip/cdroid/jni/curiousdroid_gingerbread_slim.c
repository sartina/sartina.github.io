#define _GNU_SOURCE
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <string.h>
#include <termios.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <string.h>

#include <jni.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

#include "hook.h"
#include "dexstuff.h"
#include "dalvik_hook.h"
#include "base.h"
#include "log.h"

#undef log
#define log(...) \
        {FILE *fp = fopen("/data/local/tmp/log", "a+");\
        fprintf(fp, __VA_ARGS__);\
        fclose(fp);}

void __attribute__ ((constructor)) my_init(void);

static struct hook_t eph;
static struct dexstuff_t d;

static void my_log(char *msg)
{
	log(msg)
}

// START --- change stuff ---
static struct dalvik_hook_t sb0;
static struct dalvik_hook_t sb1;
static struct dalvik_hook_t sb2;

void* loadclass(JNIEnv *env);
void* run_curiousdroid(JNIEnv *env, jobject obj, int type, int r);
int startlistener();

int startup = 1;
int viewcalled = 0;
int hold_print = 0;
int previous_func_call = 999;
jobject seedview, seeddialog,  seedintent, curract;
int stopintent, isroot, isrootactivity;
// global for the loaded class
void *cdroid;
jobject viewlist;
void* viewnodecls;
void* cdroid_class;
//uint8_t root;
time_t curtime;
struct timeval t;

void* reflect_call(JNIEnv *env, jobject obj, char *name, void* sig, jvalue *args)
{
	jclass cl = (*env)->FindClass(env, "java/lang/Class");
	jmethodID mid = (*env)->GetMethodID(env, cl, "getMethod","(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
	
	jmethodID mid2 = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid2)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid2, 0);
	log("obj2 = %#x\n", obj2)
	
	jvalue args1[5];
	args1[0].l = (*env)->NewStringUTF(env, name);
	args1[1].l = sig;
	jobject obj3 = (*env)->CallObjectMethodA(env, obj2, mid, args1);
	log("getMethod = %#x\n", obj3)
	
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	mid = (*env)->GetMethodID(env, cl, "invoke","(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");
	log("invoke mid = %#x\n", mid)
	args[0].l = obj;
	jobject obj4 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("obj4 = %#x\n", obj4)
	
	return obj4;
}

jobject loadclass_a23(JNIEnv *env, jobject obj, char *dexfile, char *dexclass, char *outerclass)
{
	// init dexclassloader
	jclass clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	jstring dp = (*env)->NewStringUTF(env, dexfile);
	jstring out = (*env)->NewStringUTF(env, "/data/local/tmp/cache");
	
	// get classloader from outerclass
	jclass cl = (*env)->FindClass(env, outerclass);
	log("cl = %#x\n", cl)
	jmethodID mid = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid, 0);
	log("obj2 = %#x\n", obj2)
	cl = (*env)->FindClass(env, "java/lang/Class");
	log("cl =- %#x\n", cl)
	mid = (*env)->GetMethodID(env, cl, "getClassLoader","()Ljava/lang/ClassLoader;");
	log("mid = %#x\n", mid)
	
	
	// create instance of dexclassloader
	obj2 = (*env)->CallObjectMethodA(env, obj2, mid, 0);
	log("classloder = %#x\n", obj2)	

	// create instance of newly loaded class			
	jobject obj3 = 0;
	jmethodID constructor = (*env)->GetMethodID(env, clc, "<init>","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
	if (constructor) {
		jvalue args[4];
		args[0].l = dp;
		args[1].l = out;
		args[2].l = 0;
		args[3].l = obj2;

		obj3 = (*env)->NewObjectA(env, clc, constructor, args);
		log("new class loader: new obj = 0x%x\n", obj3)
		
		if (!obj3)
			log("failed to create class loader, FATAL!\n")
	}
	else {
		log("constructor == 0\n")
	}
	
	// load class using dexclassloader
	clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	mid = (*env)->GetMethodID(env, clc, "loadClass","(Ljava/lang/String;)Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jvalue args[1];
	args[0].l = (*env)->NewStringUTF(env, dexclass);
	obj2 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("loaded = %#x\n", obj2)
	
	// new instance of newly loaded class
	cl = (*env)->FindClass(env, "java/lang/Class");
	mid = (*env)->GetMethodID(env, cl, "newInstance", "()Ljava/lang/Object;");
	log("newinstance mid = %#x\n", mid)
	jobject obj4 = (*env)->CallObjectMethodA(env, obj2, mid, args);
	log("instance = %#x\n", obj4)
	
	
	return (*env)->NewGlobalRef(env, obj4);
	
	/*
	cl = (*env)->FindClass(env, "java/lang/Class");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	*/
}

static void printString(JNIEnv *env, jobject str, char *l, int r)
{
	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {//} && !hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: %s%s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, l, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
}

static void* sb0_onresume(JNIEnv *env, jobject obj) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: sb0_onresume BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	previous_func_call = 1;

	if(startup) {
		jclass act = (*env)->FindClass(env, "android/app/Activity");

		jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("GetMethodID-getWindow did not work.\n")
		log("jmid_win = 0x%x\n", jmid_win)

		jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("getWindow() did not work.\n")
		log("window = 0x%x\n", window)
jclass
		 win       = (*env)->FindClass(env, "android/view/Window");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("FindClass-Window did not work.\n")

		jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("getMethodID-getDecorView did not work.\n")
		log("jmid_view = 0x%x\n", jmid_view)

		jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("CallObjectMethod-getDecorView did not work.\n")
		log("view = 0x%x\n", view)

		seedview = (*env)->NewGlobalRef(env, view);
		run_curiousdroid(env, obj, 1000, r);
		startup = 0;
	}
	dalvik_prepare(&d, &sb0, env);
	(*env)->CallVoidMethod(env, obj, sb0.mid, NULL); 
	dalvik_postcall(&d, &sb0);
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: sb0_onresume END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("\n")
	return;
}

static void* onwindowfocuschanged(JNIEnv *env,  jobject obj, jboolean hasfocus) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: onwindowfocuschanged BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb1, env);
	(*env)->CallVoidMethod(env, obj, sb1.mid, hasfocus);
	uint8_t focus = (uint8_t)hasfocus;
	previous_func_call = 2;

	if(focus) {
		jclass act = (*env)->FindClass(env, "android/app/Activity");
		jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
		jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
		jclass win       = (*env)->FindClass(env, "android/view/Window");
		jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
		jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
		seedview = (*env)->NewGlobalRef(env, view);
		run_curiousdroid(env, obj, 0, r);
	}
	
	dalvik_postcall(&d, &sb1);
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: onwindowfocuschanged END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("\n")
	return;
}

static void* ondialog(JNIEnv *env,  jobject obj, jboolean hasfocus) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: ondialog BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	previous_func_call = 3;

	dalvik_prepare(&d, &sb2, env);
	(*env)->CallVoidMethod(env, obj, sb2.mid, hasfocus); 
	uint8_t focus = (uint8_t)hasfocus;

	if(focus) {
		jclass dialog = (*env)->FindClass(env, "android/app/Dialog");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem finding Dialog class.\n")
		log("dialog = 0x%x\n", dialog)

		jfieldID mDecor = (*env)->GetFieldID(env, dialog, "mDecor", "Landroid/view/View;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Could not get fieldID mDecor\n")
		log("mDecor = 0x%x\n", mDecor)

		jobject view = (*env)->GetObjectField(env, obj, mDecor);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Could not get field object view.\n")
		log("view = 0x%x\n", view)
		seedview = (*env)->NewGlobalRef(env, view);
		run_curiousdroid(env, obj, 1, r);
	}
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: success calling : Dialog.%s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, sb2.method_name)
	
	dalvik_postcall(&d, &sb2);
	log("\n")
}






void do_patch_onresume()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb0,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onResume",//onResume", // method name
		"()V", // method signature: (ARGUMENTS in L format)Return_value
		1, // paramter size = number of args + 1 (if method not static)
		sb0_onresume); // function to use for patch
	dalvik_hook(&d, &sb0);
	
}

void do_patch_alertdialog()
{
	dalvik_hook_setup(
		&sb2,
		"Landroid/app/Dialog;",
		"onWindowFocusChanged",
		"(Z)V",
		2,
		ondialog);
	dalvik_hook(&d, &sb2);
}

void do_patch_onfocuschange()
{
	dalvik_hook_setup(
		&sb1, 
		"Landroid/app/Activity;",
		"onWindowFocusChanged", 
		"(Z)V",
		2,
		onwindowfocuschanged);
	dalvik_hook(&d, &sb1);
}


int sock, len;
int listenerstarted = 0;
struct sockaddr_un remote;
jobject curiousdroid;
void* run_curiousdroid(JNIEnv *env, jobject obj, int type, int r)
{
	hold_print = 1;
	jthrowable exc;
	if(viewcalled == 0) {
		log("About to load CuriousDroid\n")
		curiousdroid = loadclass_a23(env, obj, "/data/local/tmp/classes.zip","edu.neu.ccs.curiousdroid.CuriousDroid","android/app/Activity");
		log("About to setup init method\n")
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedview);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));
		
		log("About to make reflection call\n")
		jobject res = reflect_call(env, curiousdroid, "init", sig, args);


		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Couldn't generate CuriousDroid object.\n")
	}

	if(!listenerstarted) {
		int listen =  startlistener();
		if(listen < 0)
			log("Problem starting listener. Don't know why...\n")
		else
			listenerstarted = 1;
	}

	const char* jstring_c;
	jobject mystring;
	if(type == 0) {

		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 2, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedview);
		(*env)->SetObjectArrayElement(env, args[1].l, 1, (*env)->NewStringUTF(env, "false"));
		
		jobjectArray sig = (*env)->NewObjectArray(env, 2,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));
		(*env)->SetObjectArrayElement(env, sig, 1, (*env)->FindClass(env,"java/lang/String"));

		mystring = reflect_call(env, curiousdroid, "expandChildViews", sig, args);

		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandChildViews method ID.\n")
		}

		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem calling expanChildViews: mystring = %s\n", jstring_c)// mystring)
		
		viewcalled++;
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call expandChildViews from native side.\n")
			log("Failed calling expandChildViews.\n")
		}
		hold_print = 0;
	}
	else if(type == 1) {
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0,seedview);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));

		mystring = reflect_call(env, curiousdroid, "expandDialogViews", sig, args);

		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandDialogViews method ID.\n")
		}
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		viewcalled++;
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call handleDialog from native side.\n")
			log("Failed calling handleDialog.\n")
		}
		hold_print = 0;
	}
	else if(type == 2) {
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedintent);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/content/Intent"));

		mystring = reflect_call(env, curiousdroid, "stopIntent", sig, args);
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call stopIntent from native side.\n")
			log("Failed calling stopIntent.\n")
		}
		uint8_t stop;

		if(strstr(jstring_c, "true"))
			stop = 1;
		else
			stop = 0;
		log("libcurious: run_curiousdroid: stop = %d\n", stop)
		stopintent = stop;
		hold_print = 0;
		viewcalled++;
		return;
	}
	else if(type == 3) {
		log("About to define isRoot method\n")

		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, curract);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/app/Activity"));

		mystring = reflect_call(env, curiousdroid, "checkRoot", sig, args);
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed calling isRoot.\n")
		}
		log("About to set root to value of isroot\n")

		if(strstr(jstring_c, "true"))
			isroot = 1;
		else
			isroot = 0;
		if(isroot)
			log("isroot = true -> %d\n", isroot)
		else
			log("isroot = flase -> %d\n", isroot)
		hold_print = 0;
		viewcalled++;
		(*env)->ReleaseStringUTFChars(env, mystring, jstring_c);
		return;
	}
	else {
		log("Called from onResume.\n")
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 2, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedview);
		(*env)->SetObjectArrayElement(env, args[1].l, 1, (*env)->NewStringUTF(env, "true"));
		
		jobjectArray sig = (*env)->NewObjectArray(env, 2,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));
		(*env)->SetObjectArrayElement(env, sig, 1, (*env)->FindClass(env,"java/lang/String"));

		mystring = reflect_call(env, curiousdroid, "expandChildViews", sig, args);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandChildViews method ID.\n")
		}
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem calling expanChildViews: mystring = %s\n", jstring_c)// mystring)
		
		(*env)->ReleaseStringUTFChars(env, mystring, jstring_c); 
		viewcalled++;
		hold_print = 0;
		return;
	}

	hold_print = 0;
	
	/*isrootactivity = "root";
	if(send(sock, isrootactivity, strlen(isrootactivity), 0) == -1) {
		log("Unable to send root event.\n")
	}*/
	if(send(sock, jstring_c, strlen(jstring_c), 0) == -1) {
		log("Unable to send event.\n")
	}
	else {
		log("Send complete.\n")
	}
	(*env)->ReleaseStringUTFChars(env, mystring, jstring_c); 

}

int startlistener() {
	if((sock = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
			log("Couldn't create a socket\n")
		}

		remote.sun_family = AF_UNIX;
		strcpy(remote.sun_path, "/data/local/tmp/eventsocket");
		len = strlen(remote.sun_path) + sizeof(remote.sun_family);
		if(connect(sock, (struct sockaddr *)&remote, len) == -1) {
			log("Unable to connect socket to listener\n")
			return -1;
		}

		return 0;
}

static int my_epoll_wait(int epfd, struct epoll_event *events, int maxevents, int timeout)
{
	int (*orig_epoll_wait)(int epfd, struct epoll_event *events, int maxevents, int timeout);
	srand(1013);
    orig_epoll_wait = (void*)eph.orig;

    hook_precall(&eph);

    dexstuff_resolv_dvm(&d);
    //
	do_patch_onresume();
	do_patch_alertdialog();
	do_patch_onfocuschange();
    int res = orig_epoll_wait(epfd, events, maxevents, timeout);
   return res;
}

void my_init(void)
{
	log("%s started\n", __FILE__)
 
 	// for libbase
	set_logfunction(my_log);
	// for libdalvikhook
	dalvikhook_set_logfunction(my_log);

    hook(&eph, getpid(), "libc.", "epoll_wait", my_epoll_wait, 0);
}