#define _GNU_SOURCE
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <string.h>
#include <termios.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <string.h>

#include <jni.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

#include "hook.h"
#include "dexstuff.h"
#include "dalvik_hook.h"
#include "base.h"
#include "log.h"

#undef log
#define log(...) \
        {FILE *fp = fopen("/data/local/tmp/log", "a+");\
        fprintf(fp, __VA_ARGS__);\
        fclose(fp);}

void __attribute__ ((constructor)) my_init(void);

static struct hook_t eph;
static struct dexstuff_t d;

static void my_log(char *msg)
{
	log(msg)
}

// START --- change stuff ---
//static struct dalvik_hook_t sb0;
static struct dalvik_hook_t sb1;

void* loadclass(JNIEnv *env);

/*static void //gencoverage() {
	system("am broadcast -a edu.gatech.m3.emma.COLLECT_COVERAGE");
}*/


void* reflect_call(JNIEnv *env, jobject obj, char *name, void* sig, jvalue *args)
{
	jclass cl = (*env)->FindClass(env, "java/lang/Class");
	jmethodID mid = (*env)->GetMethodID(env, cl, "getMethod","(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
	
	jmethodID mid2 = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid2)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid2, 0);
	log("obj2 = %#x\n", obj2)
	
	jvalue args1[5];
	args1[0].l = (*env)->NewStringUTF(env, name);
	args1[1].l = sig;
	jobject obj3 = (*env)->CallObjectMethodA(env, obj2, mid, args1);
	log("getMethod = %#x\n", obj3)
	
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	mid = (*env)->GetMethodID(env, cl, "invoke","(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");
	log("invoke mid = %#x\n", mid)
	args[0].l = obj;
	jobject obj4 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("obj4 = %#x\n", obj4)
	
	return obj4;
}

jobject loadclass_a23(JNIEnv *env, jobject obj, char *dexfile, char *dexclass, char *outerclass)
{
	// init dexclassloader
	jclass clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	jstring dp = (*env)->NewStringUTF(env, dexfile);
	jstring out = (*env)->NewStringUTF(env, "/data/local/tmp/cache");
	
	// get classloader from outerclass
	jclass cl = (*env)->FindClass(env, outerclass);
	log("cl = %#x\n", cl)
	jmethodID mid = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid, 0);
	log("obj2 = %#x\n", obj2)
	cl = (*env)->FindClass(env, "java/lang/Class");
	log("cl =- %#x\n", cl)
	mid = (*env)->GetMethodID(env, cl, "getClassLoader","()Ljava/lang/ClassLoader;");
	log("mid = %#x\n", mid)
	
	
	// create instance of dexclassloader
	obj2 = (*env)->CallObjectMethodA(env, obj2, mid, 0);
	log("classloder = %#x\n", obj2)	

	// create instance of newly loaded class			
	jobject obj3 = 0;
	jmethodID constructor = (*env)->GetMethodID(env, clc, "<init>","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
	if (constructor) {
		jvalue args[4];
		args[0].l = dp;
		args[1].l = out;
		args[2].l = 0;
		args[3].l = obj2;

		obj3 = (*env)->NewObjectA(env, clc, constructor, args);
		log("new class loader: new obj = 0x%x\n", obj3)
		
		if (!obj3)
			log("failed to create class loader, FATAL!\n")
	}
	else {
		log("constructor == 0\n")
	}
	
	// load class using dexclassloader
	clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	mid = (*env)->GetMethodID(env, clc, "loadClass","(Ljava/lang/String;)Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jvalue args[1];
	args[0].l = (*env)->NewStringUTF(env, dexclass);
	obj2 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("loaded = %#x\n", obj2)
	
	// new instance of newly loaded class
	cl = (*env)->FindClass(env, "java/lang/Class");
	mid = (*env)->GetMethodID(env, cl, "newInstance", "()Ljava/lang/Object;");
	log("newinstance mid = %#x\n", mid)
	jobject obj4 = (*env)->CallObjectMethodA(env, obj2, mid, args);
	log("instance = %#x\n", obj4)
	
	
	return (*env)->NewGlobalRef(env, obj4);
	
	/*
	cl = (*env)->FindClass(env, "java/lang/Class");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	*/
}

static void* onwindowfocuschanged(JNIEnv *env,  jobject obj, jboolean hasfocus) {
	dalvik_prepare(&d, &sb1, env);
	(*env)->CallVoidMethod(env, obj, sb1.mid, hasfocus);
	uint8_t focus = (uint8_t)hasfocus;

	if(focus) {
		jclass act = (*env)->FindClass(env, "android/app/Activity");
		jmethodID jmid_getclass  = (*env)->GetMethodID(env, act, "getClass", "()Ljava/lang/Class;");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("GetMethodID: getClass from activity did not work.\n")

		jobject classobj = (*env)->CallObjectMethod(env, obj, jmid_getclass);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("CallObjectMethod Activity->getClass() did not work.\n")

		jclass clazz = (*env)->FindClass(env, "java/lang/Class");
		jmethodID jmid_getname = (*env)->GetMethodID(env, clazz, "getName", "()Ljava/lang/String;");

		jobject classname = (*env)->CallObjectMethod(env, classobj, jmid_getname);
		char *s = (*env)->GetStringUTFChars(env, classname, 0);
		if(s)
			log("ActivityTriggered: %s\n", s)
	}
	
	dalvik_postcall(&d, &sb1);
	return;
}

void do_patch_onfocuschange()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onWindowFocusChanged", // method name
		"(Z)V", // method signature: (ARGUMENTS in L format)Return_value
		2, // paramter size = number of args + 1 (if method not static)
		onwindowfocuschanged); // function to use for dalvik_hook
	dalvik_hook(&d, &sb1);
}



// END --- load class

// ---- don't need to modify ----

static int my_epoll_wait(int epfd, struct epoll_event *events, int maxevents, int timeout)
{
	int (*orig_epoll_wait)(int epfd, struct epoll_event *events, int maxevents, int timeout);
	srand(1013);
    orig_epoll_wait = (void*)eph.orig;
    hook_precall(&eph);
    dexstuff_resolv_dvm(&d);
	do_patch_onfocuschange();
    int res = orig_epoll_wait(epfd, events, maxevents, timeout);
   return res;
}

void my_init(void)
{
	log("%s started\n", __FILE__)
 
 	// for libbase
	set_logfunction(my_log);
	// for libdalvikhook
	dalvikhook_set_logfunction(my_log);

    hook(&eph, getpid(), "libc.", "epoll_wait", my_epoll_wait, 0);
}