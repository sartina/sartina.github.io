#define _GNU_SOURCE
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <string.h>
#include <termios.h>
#include <sys/epoll.h>
#include <sys/time.h>
#include <string.h>

#include <jni.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

#include "hook.h"
#include "dexstuff.h"
#include "dalvik_hook.h"
#include "base.h"
#include "log.h"

#undef log
#define log(...) \
        {FILE *fp = fopen("/data/local/tmp/log", "a+");\
        fprintf(fp, __VA_ARGS__);\
        fclose(fp);}

void __attribute__ ((constructor)) my_init(void);

static struct hook_t eph;
static struct dexstuff_t d;

static void my_log(char *msg)
{
	log(msg)
}

// START --- change stuff ---
static struct dalvik_hook_t sb0;
static struct dalvik_hook_t sb1;
static struct dalvik_hook_t sb2;
static struct dalvik_hook_t sb3;
static struct dalvik_hook_t sb4;
static struct dalvik_hook_t sb5;
static struct dalvik_hook_t sb6;
static struct dalvik_hook_t sb7;
static struct dalvik_hook_t sb8;
static struct dalvik_hook_t sb9;
static struct dalvik_hook_t sb10;
static struct dalvik_hook_t sb11;
static struct dalvik_hook_t sb12;
static struct dalvik_hook_t sb13;
static struct dalvik_hook_t sb14;
static struct dalvik_hook_t sb15;
static struct dalvik_hook_t sb16;
static struct dalvik_hook_t sb17;
static struct dalvik_hook_t sb18;
static struct dalvik_hook_t sb19;
static struct dalvik_hook_t sb20;
static struct dalvik_hook_t sb21;
static struct dalvik_hook_t sb22;
static struct dalvik_hook_t sb23;
static struct dalvik_hook_t sb24;
static struct dalvik_hook_t sb25;
static struct dalvik_hook_t sb26;
static struct dalvik_hook_t sb27;
static struct dalvik_hook_t sb28;
static struct dalvik_hook_t sb29;
static struct dalvik_hook_t sb30;
static struct dalvik_hook_t sb31;
static struct dalvik_hook_t sb32;
static struct dalvik_hook_t sb33;
static struct dalvik_hook_t sb34;
static struct dalvik_hook_t sb35;
static struct dalvik_hook_t sb36;
static struct dalvik_hook_t sb37;
static struct dalvik_hook_t sb38;
static struct dalvik_hook_t sb39;
static struct dalvik_hook_t sb40;
static struct dalvik_hook_t sb41;
static struct dalvik_hook_t sb42;
static struct dalvik_hook_t sb43;
static struct dalvik_hook_t sb44;
static struct dalvik_hook_t sb45;
static struct dalvik_hook_t sb46;
static struct dalvik_hook_t sb47;
static struct dalvik_hook_t sb48;
static struct dalvik_hook_t sb49;
static struct dalvik_hook_t sb50;
static struct dalvik_hook_t sb51;
static struct dalvik_hook_t sb52;
static struct dalvik_hook_t sb53;
static struct dalvik_hook_t sb54;
static struct dalvik_hook_t sb55;
static struct dalvik_hook_t sb56;
static struct dalvik_hook_t sb57;
static struct dalvik_hook_t sb58;
static struct dalvik_hook_t sb60;

void* loadclass(JNIEnv *env);
void* run_curiousdroid(JNIEnv *env, jobject obj, int type, int r);
int startlistener();

int startup = 1;
int viewcalled = 0;
int hold_print = 0;
int previous_func_call = 999;
jobject seedview, seeddialog,  seedintent, curract;
int stopintent, isroot, isrootactivity;
// global for the loaded class
void *cdroid;
jobject viewlist;
void* viewnodecls;
void* cdroid_class;
//uint8_t root;
time_t curtime;
struct timeval t;

/*static void //gencoverage() {
	system("am broadcast -a edu.gatech.m3.emma.COLLECT_COVERAGE");
}*/


void* reflect_call(JNIEnv *env, jobject obj, char *name, void* sig, jvalue *args)
{
	jclass cl = (*env)->FindClass(env, "java/lang/Class");
	jmethodID mid = (*env)->GetMethodID(env, cl, "getMethod","(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
	
	jmethodID mid2 = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid2)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid2, 0);
	log("obj2 = %#x\n", obj2)
	
	jvalue args1[5];
	args1[0].l = (*env)->NewStringUTF(env, name);
	args1[1].l = sig;
	jobject obj3 = (*env)->CallObjectMethodA(env, obj2, mid, args1);
	log("getMethod = %#x\n", obj3)
	
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	mid = (*env)->GetMethodID(env, cl, "invoke","(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");
	log("invoke mid = %#x\n", mid)
	args[0].l = obj;
	jobject obj4 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("obj4 = %#x\n", obj4)
	
	return obj4;
}

jobject loadclass_a23(JNIEnv *env, jobject obj, char *dexfile, char *dexclass, char *outerclass)
{
	// init dexclassloader
	jclass clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	jstring dp = (*env)->NewStringUTF(env, dexfile);
	jstring out = (*env)->NewStringUTF(env, "/data/local/tmp/cache");
	
	// get classloader from outerclass
	jclass cl = (*env)->FindClass(env, outerclass);
	log("cl = %#x\n", cl)
	jmethodID mid = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid, 0);
	log("obj2 = %#x\n", obj2)
	cl = (*env)->FindClass(env, "java/lang/Class");
	log("cl =- %#x\n", cl)
	mid = (*env)->GetMethodID(env, cl, "getClassLoader","()Ljava/lang/ClassLoader;");
	log("mid = %#x\n", mid)
	
	
	// create instance of dexclassloader
	obj2 = (*env)->CallObjectMethodA(env, obj2, mid, 0);
	log("classloder = %#x\n", obj2)	

	// create instance of newly loaded class			
	jobject obj3 = 0;
	jmethodID constructor = (*env)->GetMethodID(env, clc, "<init>","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
	if (constructor) {
		jvalue args[4];
		args[0].l = dp;
		args[1].l = out;
		args[2].l = 0;
		args[3].l = obj2;

		obj3 = (*env)->NewObjectA(env, clc, constructor, args);
		log("new class loader: new obj = 0x%x\n", obj3)
		
		if (!obj3)
			log("failed to create class loader, FATAL!\n")
	}
	else {
		log("constructor == 0\n")
	}
	
	// load class using dexclassloader
	clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	mid = (*env)->GetMethodID(env, clc, "loadClass","(Ljava/lang/String;)Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jvalue args[1];
	args[0].l = (*env)->NewStringUTF(env, dexclass);
	obj2 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("loaded = %#x\n", obj2)
	
	// new instance of newly loaded class
	cl = (*env)->FindClass(env, "java/lang/Class");
	mid = (*env)->GetMethodID(env, cl, "newInstance", "()Ljava/lang/Object;");
	log("newinstance mid = %#x\n", mid)
	jobject obj4 = (*env)->CallObjectMethodA(env, obj2, mid, args);
	log("instance = %#x\n", obj4)
	
	
	return (*env)->NewGlobalRef(env, obj4);
	
	/*
	cl = (*env)->FindClass(env, "java/lang/Class");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	*/
}

static void printString(JNIEnv *env, jobject str, char *l, int r)
{
	//struct timeval t;
	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {//} && !hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: %s%s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, l, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
}

static void* sb0_onresume(JNIEnv *env, jobject obj) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: sb0_onresume BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	previous_func_call = 1;

	if(startup) {
		jclass act = (*env)->FindClass(env, "android/app/Activity");

		jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("GetMethodID-getWindow did not work.\n")
		log("jmid_win = 0x%x\n", jmid_win)

		jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("getWindow() did not work.\n")
		log("window = 0x%x\n", window)

		jclass win       = (*env)->FindClass(env, "android/view/Window");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("FindClass-Window did not work.\n")

		jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("getMethodID-getDecorView did not work.\n")
		log("jmid_view = 0x%x\n", jmid_view)

		jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("CallObjectMethod-getDecorView did not work.\n")
		log("view = 0x%x\n", view)

		seedview = (*env)->NewGlobalRef(env, view);
		run_curiousdroid(env, obj, 1000, r);
		startup = 0;
	}
	dalvik_prepare(&d, &sb0, env);
	(*env)->CallVoidMethod(env, obj, sb0.mid, NULL); 
	dalvik_postcall(&d, &sb0);
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: sb0_onresume END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("\n")
	return;
}

static void* onwindowfocuschanged(JNIEnv *env,  jobject obj, jboolean hasfocus) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: onwindowfocuschanged BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb1, env);
	(*env)->CallVoidMethod(env, obj, sb1.mid, hasfocus);
	uint8_t focus = (uint8_t)hasfocus;
	previous_func_call = 2;

	if(focus) {
		jclass act = (*env)->FindClass(env, "android/app/Activity");
		jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
		jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
		jclass win       = (*env)->FindClass(env, "android/view/Window");
		jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
		jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
		seedview = (*env)->NewGlobalRef(env, view);
		run_curiousdroid(env, obj, 0, r);
	}
	
	dalvik_postcall(&d, &sb1);
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: onwindowfocuschanged END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("\n")
	return;
}

static void* ondialog(JNIEnv *env,  jobject obj, jboolean hasfocus) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: ondialog BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	previous_func_call = 3;

	dalvik_prepare(&d, &sb2, env);
	(*env)->CallVoidMethod(env, obj, sb2.mid, hasfocus); 
	uint8_t focus = (uint8_t)hasfocus;

	if(focus) {
		jclass dialog = (*env)->FindClass(env, "android/app/Dialog");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem finding Dialog class.\n")
		log("dialog = 0x%x\n", dialog)

		jfieldID mDecor = (*env)->GetFieldID(env, dialog, "mDecor", "Landroid/view/View;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Could not get fieldID mDecor\n")
		log("mDecor = 0x%x\n", mDecor)

		jobject view = (*env)->GetObjectField(env, obj, mDecor);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Could not get field object view.\n")
		log("view = 0x%x\n", view)
		seedview = (*env)->NewGlobalRef(env, view);
		//gencoverage();
		run_curiousdroid(env, obj, 1, r);
	}
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: success calling : Dialog.%s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, sb2.method_name)
	
	dalvik_postcall(&d, &sb2);
	log("\n")
}

static void* sb29_sendtextmessage(JNIEnv *env, jobject obj, jobject str) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb29_sendtextmessage BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb29, env);
	(*env)->CallVoidMethodA(env, obj, sb29.mid, args);

	if(str) {
		char *s = (*env)->GetStringUTFChars(env, str, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb29.sendtextmessage = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb29);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb29_sendtextmessage END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb30_senddatamessage(JNIEnv *env, jobject obj, jobject str1, jobject str2, jshort port,
	jbyteArray data, jobject sintent, jobject dintent) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb30_senddatamessage BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	/*jvalue args[6];
	args[0].l = str1;
	args[1].l = str2;
	args[2].s = port;
	args[3].b = &data;
	args[4].l = sintent;
	args[5].l = dintent;*/

	dalvik_prepare(&d, &sb30, env);
	(*env)->CallVoidMethod(env, obj, sb30.mid, str1, str2, port, data, sintent, dintent);

	if(str1 && str2) {
		//if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb30.senddatamessage => destAddr: %s, SrcAddr: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, str1, str2)
		//}
	}
	(*env)->ReleaseStringUTFChars(env, str1, str2); 
	dalvik_postcall(&d, &sb30);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb30_senddatamessage END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb31_getmessagebody(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb31_getmessagebody BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb31, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb31.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb31.getmessagebody = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb31);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb31_getsimplename END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb32_getorigiatingaddress(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb32_getorigiatingaddress BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb32, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb32.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb32.getoriginatingaddress = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
			(*env)->ReleaseStringUTFChars(env, res, s);
		}
	}
	 
	dalvik_postcall(&d, &sb32);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb32_getorigiatingaddress END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb33_getservicecenteraddress(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb33_getservicecenteraddress BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb33, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb33.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb33.getservicecenteraddress = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb33);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb33_getservicecenteraddress END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb34_execute(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb34_execute BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
//	}

	dalvik_prepare(&d, &sb34, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb34.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb34.execute = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
		//	}
			(*env)->ReleaseStringUTFChars(env, res, s); 
		}
	}
	
	dalvik_postcall(&d, &sb34);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb34_execute END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb35_fromparts(JNIEnv *env, jobject obj, jobject str1, jobject str2, jobject str3) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb35_fromparts BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb35, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb35.mid, str1, str2, str3);

	if(str1 || str2 || str3) {
		//if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb35.fromparts => scheme: %s, ssp: %s, fragment: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, str1, str2, str3)
		//}
	}
	dalvik_postcall(&d, &sb35);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb35_fromparts END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb36_withappendedpaths(JNIEnv *env, jobject obj, jobject uri, jobject str) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb36_withappendedpaths BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb36, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb36.mid, uri, str);

	if(str) {
		//if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb36.withAppendedPaths => pathsegment: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, str)
		//}
	}
	dalvik_postcall(&d, &sb36);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb36_withappendedpaths END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb37_tostring(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(1) {//!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb37_tostring BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb37, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb37.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			if(1) {//!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb37.tostring = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			}
			(*env)->ReleaseStringUTFChars(env, res, s);
		}
	}
	 
	dalvik_postcall(&d, &sb37);
	if(1) {//!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb37_tostring END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	}
	return res;
}

static void* sb42_gethostname(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	////if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb42_gethostname BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
//	}
	log("libcurious: %lu%lu-%d: sb42_gethostname: about to call CallObjectMethod\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	void* res = (*env)->CallObjectMethod(env, obj, sb42.mid, NULL);
	log("libcurious: %lu%lu-%d: sb42_gethostname: just called CallObjectMethod\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		////if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb42.gethostname => host: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
		//}
		(*env)->ReleaseStringUTFChars(env, res, s);
	}
	 
	dalvik_postcall(&d, &sb42);
	////if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb42_gethostname END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;	
}

static void* sb43_startactivity(JNIEnv *env, jobject obj, jobject intent) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: sb43_startactivity BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//log("libcurious: sb43_startactivity: about to set global reference on intent\n")
	seedintent = (*env)->NewGlobalRef(env, intent);
	//log("libcurious: sb43_startactivity: that worked, next is checking for startup value\n")
	previous_func_call = 0;
	
	if(startup) {
		dalvik_prepare(&d, &sb43, env);
		log("libcurious: sb43_startactivity: CallVoidMethod(env, obj, sb43.mid, intent)\n")
		(*env)->CallVoidMethod(env, obj, sb43.mid, intent);
		log("libcurious: sb43_startactivity: dalvik_postcall\n")
		dalvik_postcall(&d, &sb43);
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: sb43_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	//log("libcurious: sb43_startactivity: startup = false.  looking for jmid \"stopIntent\"\n")
	//jmethodID jmid = (*env)->GetMethodID(env, cdroid, "stopIntent", "(Landroid/content/Intent;)Z;");
	//log("libcurious: sb43_startactivity: jmid = 0x%x. Calling stopIntent\n", jmid)
	//jboolean stopintent = (*env)->CallBooleanMethod(env, cdroid_class, jmid, globalintent);
	run_curiousdroid(env, obj, 2, r);
	uint8_t stop = (uint8_t)stopintent;
	log("libcurious: sb43_startactivity: stop = %d\n", stop)
	

	if(stop) {
		log("libcurious: sb43_startactivity: stop = %d -> Blocking activity call...\n", stop)
		log("libcurious: %lu.%lu-%d: sb43_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		previous_func_call = -1;
		return;
	}
	else {
		log("libcurious: sb43_startactivity: stop = %d so I'll let this one fly.\n", stop)
		dalvik_prepare(&d, &sb43, env);
		(*env)->CallVoidMethod(env, obj, sb43.mid, intent);
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Problem calling the original startActivity method.\n")
		}else
			log("No problems calling the original startActivity method.\n")
		dalvik_postcall(&d, &sb43);
		log("libcurious: %lu.%lu-%d: sb43_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}

}

static void* sb45_startactivityforresult(JNIEnv *env, jobject obj, jobject intent, jint requestcode) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: sb45_startactivityforresult BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//log("libcurious: sb45_startactivityforresult: about to set global reference on intent\n")
	seedintent = (*env)->NewGlobalRef(env, intent);
	//log("libcurious: sb45_startactivityforresult: that worked, next is checking for startup value\n")
	previous_func_call = 0;
	
	if(startup) {
		dalvik_prepare(&d, &sb45, env);
		log("libcurious: sb45_startactivityforresult: CallVoidMethod(env, obj, sb45.mid, intent)\n")
		(*env)->CallVoidMethod(env, obj, sb45.mid, intent, requestcode);
		log("libcurious: sb45_startactivityforresult: dalvik_postcall\n")
		dalvik_postcall(&d, &sb45);
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: sb45_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	//log("libcurious: sb45_startactivityforresult: startup = false.  looking for jmid \"stopIntent\"\n")
	//jmethodID jmid = (*env)->GetMethodID(env, cdroid, "stopIntent", "(Landroid/content/Intent;)Z;");
	//log("libcurious: sb45_startactivityforresult: jmid = 0x%x. Calling stopIntent\n", jmid)
	//jboolean stopintent = (*env)->CallBooleanMethod(env, cdroid_class, jmid, globalintent);
	run_curiousdroid(env, obj, 2, r);
	uint8_t stop = (uint8_t)stopintent;
	log("libcurious: sb45_startactivityforresult: stop = %d\n", stop)
	

	if(stop) {
		log("libcurious: sb45_startactivityforresult: stop = %d -> Blocking activity call...\n", stop)
		log("libcurious: %lu.%lu-%d: sb45_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		previous_func_call = -1;
		return;
	}
	else {
		log("libcurious: sb45_startactivityforresult: stop = %d so I'll let this one fly.\n", stop)
		dalvik_prepare(&d, &sb45, env);
		(*env)->CallVoidMethod(env, obj, sb45.mid, intent, requestcode);
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Problem calling the original startActivityForResult method.\n")
		}else
			log("No problems calling the original startActivityForResult method.\n")
		dalvik_postcall(&d, &sb45);
		log("libcurious: %lu.%lu-%d: sb45_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}

}

static void* sb47_finish(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: sb47_finish BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	jclass act = (*env)->FindClass(env, "android/app/Activity");
	//log("Just called FindClass in sb47.\n")
	jthrowable exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling FindClass-Activity in sb47.\n")
	}
	jmethodID getlocalclassname = (*env)->GetMethodID(env, act, "getLocalClassName", "()Ljava/lang/String;");
	exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling GetMethodID-getLocalClassName in sb47.\n")
	}
	jstring classname = (*env)->CallObjectMethod(env, obj, getlocalclassname);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling CallObjectMethod-getLocalClassName in sb47.\n")
	}
	char *s = (*env)->GetStringUTFChars(env, classname, 0);
	log("Activity name = %s\n", s)
	(*env)->ReleaseStringUTFChars(env, classname, s); 
	jmethodID jmid =  (*env)->GetMethodID(env, act, "isTaskRoot", "()Z");
	//log("Just called GetMethodID in sb47.\n")
	exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling GetMethodID-isTaskRoot in sb47.\n")
	}
	jboolean isroot2 = (*env)->CallBooleanMethod(env, obj, jmid);
	log("Just called CallBooleanMethod in sb47.\n")
	exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling CallBooleanMethod in sb47.\n")
	}
	curract = (*env)->NewGlobalRef(env, obj);
	uint8_t root;// = (uint8_t)isroot;
	if(!startup) {
		run_curiousdroid(env, obj, 3, r);
		uint8_t root2 = (uint8_t)isroot2;
		log("About to test isroot as uint8_t.\n")
		root = (uint8_t)isroot;
	}
	else {
		root = 1;
		startlistener();
	}

	if(root && previous_func_call) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: sb47_finish -> blocking finish call.\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: sb47_finish END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	else {
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: sb47_finish: Not root task.  Allowing finish() call to run.\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		dalvik_prepare(&d, &sb47, env);
		(*env)->CallVoidMethod(env, obj, sb47.mid);
		dalvik_postcall(&d, &sb47);
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu-%d: sb47_finish END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	}
	previous_func_call = 4;
}

static void* sb53_loadurl(JNIEnv *env, jobject obj, jobject url) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb53_loadurl BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb53, env);
	(*env)->CallVoidMethod(env, obj, sb53.mid, url);
	dalvik_postcall(&d, &sb53);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb53_loadurl END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb54_loadurl(JNIEnv *env, jobject obj, jobject url, jobject map) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb54_loadurl BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb54, env);
	(*env)->CallVoidMethod(env, obj, sb54.mid, url, map);
	dalvik_postcall(&d, &sb54);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb54_loadurl END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb55_loaddatabaseurl(JNIEnv *env, jobject obj, jobject url, jobject data, jobject mimetype, jobject encoding, jobject histurl) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb55, env);
	(*env)->CallVoidMethod(env, obj, sb55.mid, url, data, mimetype, encoding, histurl);
	//char *s = (*env)->GetStringUTFChars(env, url, 0);
	printString(env, url, "sb55_loaddatabaseurl->url:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->url: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, url)
	printString(env, data, "sb55_loaddatabaseurl->data:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->data: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, data)
	printString(env, mimetype, "sb55_loaddatabaseurl->mimetype:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->mimetype: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, mimetype)
	printString(env, encoding, "sb55_loaddatabaseurl->encoding:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->encoding: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, encoding)
	printString(env, histurl, "sb55_loaddatabaseurl->histurl:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->histurl: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, histurl)
	dalvik_postcall(&d, &sb55);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb56_loaddata(JNIEnv *env, jobject obj, jobject str1, jobject str2, jobject str3) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb56_loaddata BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb56, env);
	(*env)->CallVoidMethod(env, obj, sb56.mid, str1, str2, str3);
	dalvik_postcall(&d, &sb56);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb56_loaddata END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb57_addjavascript(JNIEnv *env, jobject obj, jobject obj1, jobject str) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb57_addjavascript BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb57, env);
	(*env)->CallVoidMethod(env, obj, sb57.mid, obj1, str);
	dalvik_postcall(&d, &sb57);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb57_addjavascript END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb58_getdeviceid(JNIEnv *env, jobject obj) {
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu: sb58_getdeviceid BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec)
	previous_func_call = 5;
	dalvik_prepare(&d, &sb58, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb58.mid);
	//log("\tlibcurious: %lu.%lu: sb58_getdeviceid DeviceID (res) = %s", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, res)
	char *s = (*env)->GetStringUTFChars(env, res, 0);
	//log("\tlibcurious: %lu.%lu: sb58_getdeviceid DeviceID (s) = %s", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, s)
	//(*env)->ReleaseStringUTFChars(env, res, s);
	if(s) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu: sb58_getdeviceid DeviceID = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, s)
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu: sb58_getdeviceid END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec)
	log("\n")
	dalvik_postcall(&d, &sb58);
	return res;
}

static void* sb60_getline1number(JNIEnv *env, jobject obj) {
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu: sb60_getline1number BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec)
	previous_func_call = 6;
	dalvik_prepare(&d, &sb60, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb60.mid);
	char *s = (*env)->GetStringUTFChars(env, res, 0);
	if(s) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu.%lu: sb60_getline1number PhoneNumber = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, s)
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu: sb60_getline1number END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec)
	log("\n")
	dalvik_postcall(&d, &sb60);
	return res;
}

void do_patch_onresume()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb0,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onResume",//onResume", // method name
		"()V", // method signature: (ARGUMENTS in L format)Return_value
		1, // paramter size = number of args + 1 (if method not static)
		sb0_onresume); // function to use for patch
	dalvik_hook(&d, &sb0);
	
}

void do_patch_alertdialog()
{
	dalvik_hook_setup(
		&sb2,
		"Landroid/app/Dialog;",
		//"onResume",
		//"()V",
		"onWindowFocusChanged",
		"(Z)V",
		2,
		ondialog);
	dalvik_hook(&d, &sb2);
}

void do_patch_onfocuschange()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onWindowFocusChanged", // method name
		"(Z)V", // method signature: (ARGUMENTS in L format)Return_value
		2, // paramter size = number of args + 1 (if method not static)
		onwindowfocuschanged); // function to use for dalvik_hook
	dalvik_hook(&d, &sb1);
}

void do_patch_intentbroadcast() {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu-%d: do_patch_intentbroadcast\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_hook_setup(&sb43, "Landroid/app/Activity;", "startActivity", "(Landroid/content/Intent;)V", 2, sb43_startactivity);
	dalvik_hook(&d, &sb43);

	dalvik_hook_setup(&sb45, "Landroid/app/Activity;", "startActivityForResult", 
		"(Landroid/content/Intent;I)V", 3, sb45_startactivityforresult);
	dalvik_hook(&d, &sb45);		

	dalvik_hook_setup(&sb47, "Landroid/app/Activity;", "finish", "()V", 1, sb47_finish);
	dalvik_hook(&d, &sb47);
}

void do_patch_messaging() {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: do_patch_messaging\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_hook_setup(&sb29, "Landroid/telephony/SmsManager;", "sendTextMessage", "(Ljava/lang/String;)V", 2, sb29_sendtextmessage);
	dalvik_hook(&d, &sb29);

	dalvik_hook_setup(&sb30, "Landroid/telephony/SmsManager;", "sendDataMessage",
		"(Ljava/lang/String;Ljava/lang/String;[BLandoid/app/PendingIntent;Landroid/app/PendingIntent;)V", 6, sb30_senddatamessage);
	dalvik_hook(&d, &sb30);

	dalvik_hook_setup(&sb31, "Landroid/telephony/SmsMessage;", "getMessageBody", "()Ljava/lang/String;", 1, sb31_getmessagebody);
	dalvik_hook(&d, &sb31);

	dalvik_hook_setup(&sb32, "Landroid/telephony/SmsMessage;", "getOriginatingAddress", "()Ljava/lang/String;", 1, sb32_getorigiatingaddress);
	dalvik_hook(&d, &sb32);

	dalvik_hook_setup(&sb33, "Landroid/telephony/SmsMessage;", "getServiceCenterAddress", "()Ljava/lang/String;", 1, sb33_getservicecenteraddress);
	dalvik_hook(&d, &sb33);
}

void do_patch_networking() {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: do_patch_networking\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_hook_setup(&sb34, "Landroid/net/http/AndroidHttpClient;", "execute",
		"(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;)Lorg/apache/http/HttpResponse;", 3, sb34_execute);
	dalvik_hook(&d, &sb34);

	dalvik_hook_setup(&sb35, "Landroid/net/Uri;", "fromParts", 
		"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;", 4, sb35_fromparts);
	dalvik_hook(&d, &sb35);

	dalvik_hook_setup(&sb36, "Landroid/net/Uri;", "withAppendedPath", 
		"(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;", 3, sb36_withappendedpaths);
	dalvik_hook(&d, &sb36);

	dalvik_hook_setup(&sb37, "Landroid/net/Uri;", "toString", "()Ljava/lang/String;", 1, sb37_tostring);
	dalvik_hook(&d, &sb37);

	//dalvik_hook_setup(&sb52, "Landroid/net/Uri;", "parse", "(Ljava/lang/String;)Landroid/net/Uri;", 2, sb52_parse);
	//dalvik_hook(&d, &sb52);

//	dalvik_hook_setup(&sb41, "Ljava/net/InetAddress;", "lookupHostByName", 
//		"(Ljava/lang/String;)[Ljava/net/InetAddress;", 2, sb41_lookuphostbyname);
//	dalvik_hook(&d, &sb41);

	dalvik_hook_setup(&sb42, "Ljava/net/InetAddress;", "getHostName", "()Ljava/lang/String;", 1, sb42_gethostname);
	dalvik_hook(&d, &sb42);

	dalvik_hook_setup(&sb53, "Landroid/webkit/WebView;", "loadUrl", "(Ljava/lang/String;)V", 2, sb53_loadurl);
	dalvik_hook(&d, &sb53);

	dalvik_hook_setup(&sb54, "Landroid/webkit/WebView;", "loadUrl", "(Ljava/lang/String;Ljava/util/Map;)V", 3, sb54_loadurl);
	dalvik_hook(&d, &sb54);

	dalvik_hook_setup(&sb55, "Landroid/webkit/WebView;", "loadDataWithBaseURL", 
		"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", 6, sb55_loaddatabaseurl);
	dalvik_hook(&d, &sb55);

	dalvik_hook_setup(&sb56, "Landroid/webkit/WebView;", "loadData", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
		4, sb56_loaddata);
	dalvik_hook(&d, &sb56);

	dalvik_hook_setup(&sb57, "Landroid/webkit/WebView;", "addJavascriptInterface", "(Ljava/lang/Object;Ljava/lang/String;)V",
		3, sb57_addjavascript);
	dalvik_hook(&d, &sb57);
}

void do_patch_telephony() {
	gettimeofday(&t, NULL);
	log("libcurious: %lu.%lu: do_patch_intentbroadcast\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec)

	dalvik_hook_setup(&sb58, "Landroid/telephony/TelephonyManager;", "getDeviceId", "()Ljava/lang/String;", 1, sb58_getdeviceid);
	dalvik_hook(&d, &sb58);

	//dalvik_hook_setup(&sb59, "Landroid/telephony/TelephonyManager;", "getDeviceSoftwareVersion", "()Ljava/lang/String;", 1, sb59_getdevicesoftwareversion);
	//dalvik_hook(&d, &sb59);

	dalvik_hook_setup(&sb60, "Landroid/telephony/TelephonyManager;", "getLine1Number", "()Ljava/lang/String;", 1, sb60_getline1number);
	dalvik_hook(&d, &sb60);

	/*dalvik_hook_setup(&sb61, "Landroid/telephony/TelephonyManager;", "getNetworkCountryIso", "()Ljava/lang/String;", 1, sb61_getnetworkcountryiso);
	dalvik_hook(&d, &sb61);*/

	//dalvik_hook_setup(&sb62, "Landroid/telephony/TelephonyManager;", "getNetworkOperator", "()Ljava/lang/String;", 1, sb62_getnetworkoperator);
	//dalvik_hook(&d, &sb62);

	//dalvik_hook_setup(&sb63, "Landroid/telephony/TelephonyManager;", "getNetworkOperatorName", "()Ljava/lang/String;", 1, sb63_getnetworkoperatorname);
	//dalvik_hook(&d, &sb63);

	//dalvik_hook_setup(&sb64, "Landroid/telephony/TelephonyManager;", "getNetworkType", "()I", 1, sb64_getnetworktype);
	//dalvik_hook(&d, &sb64);

	//dalvik_hook_setup(&sb65, "Landroid/telephony/TelephonyManager;", "getPhoneType", "()I", 1, sb65_getphonetype);
	//dalvik_hook(&d, &sb65);

	//dalvik_hook_setup(&sb66, "Landroid/telephony/TelephonyManager;", "getSimCountryIso", "()Ljava/lang/String;", 1, sb66_getsimcountryiso);
	//dalvik_hook(&d, &sb66);

	/*dalvik_hook_setup(&sb67, "Landroid/telephony/TelephonyManager;", "getSimOperator", "()Ljava/lang/String;", 1, sb67_getsimoperator);
	dalvik_hook(&d, &sb67);

	dalvik_hook_setup(&sb68, "Landroid/telephony/TelephonyManager;", "getSimOperatorName", "()Ljava/lang/String;", 1, sb68_getsimoperatorname);
	dalvik_hook(&d, &sb69);

	dalvik_hook_setup(&sb69, "Landroid/telephony/TelephonyManager;", "getSimSerialNumber", "()Ljava/lang/String;", 1, sb69_getsimserialnumber);
	dalvik_hook(&d, &sb69);

	dalvik_hook_setup(&sb70, "Landroid/telephony/TelephonyManager;", "getSimState", "()I", 1, sb70_getsimmstate);
	dalvik_hook(&d, &sb70);

	dalvik_hook_setup(&sb71, "Landroid/telephony/TelephonyManager;", "getSubscriberId", "()Ljava/lang/String;", 1, sb71_getsubscriberid);
	dalvik_hook(&d, &sb71);

	dalvik_hook_setup(&sb72, "Landroid/telephony/TelephonyManager;", "getVoiceMailNumber", "()Ljava/lang/String;", 1, sb72);
	dalvik_hook(&d, &sb72);*/

}


int sock, len;
int listenerstarted = 0;
struct sockaddr_un remote;
jobject curiousdroid;
void* run_curiousdroid(JNIEnv *env, jobject obj, int type, int r)
{
	hold_print = 1;
	jthrowable exc;// = (*env)->ExceptionOccurred(env);
	if(viewcalled == 0) {
		//cdroid_class = (*env)->NewObject(env, cdroid, cdroid_init, seedview, NULL);
		//cdroid_class = (*env)->NewGlobalRef(env, cdroid_class);
		log("About to load CuriousDroid\n")
		curiousdroid = loadclass_a23(env, obj, "/data/local/tmp/classes.zip","edu.neu.ccs.curiousdroid.CuriousDroid","android/app/Activity");
		log("About to setup init method\n")
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedview);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));
		
		//jobject result = reflect_call(env, curiousdroid, "init", sig, args);
		log("About to make reflection call\n")
		jobject res = reflect_call(env, curiousdroid, "init", sig, args);


		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Couldn't generate CuriousDroid object.\n")
	}

	if(!listenerstarted) {
		int listen =  startlistener();
		if(listen < 0)
			log("Problem starting listener. Don't know why...\n")
		else
			listenerstarted = 1;
	}

	const char* jstring_c;
	jobject mystring;
	if(type == 0) {

		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 2, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedview);
		(*env)->SetObjectArrayElement(env, args[1].l, 1, (*env)->NewStringUTF(env, "false"));
		
		jobjectArray sig = (*env)->NewObjectArray(env, 2,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));
		(*env)->SetObjectArrayElement(env, sig, 1, (*env)->FindClass(env,"java/lang/String"));

		mystring = reflect_call(env, curiousdroid, "expandChildViews", sig, args);

		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandChildViews method ID.\n")
		}

		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem calling expanChildViews: mystring = %s\n", jstring_c)// mystring)
		
		viewcalled++;
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call expandChildViews from native side.\n")
			log("Failed calling expandChildViews.\n")
		}
		hold_print = 0;
	}
	else if(type == 1) {
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0,seedview);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));

		mystring = reflect_call(env, curiousdroid, "expandDialogViews", sig, args);

		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandDialogViews method ID.\n")
		}
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		viewcalled++;
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call handleDialog from native side.\n")
			log("Failed calling handleDialog.\n")
		}
		hold_print = 0;
	}
	else if(type == 2) {
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedintent);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/content/Intent"));

		mystring = reflect_call(env, curiousdroid, "stopIntent", sig, args);
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call stopIntent from native side.\n")
			log("Failed calling stopIntent.\n")
		}
		uint8_t stop;

		if(strstr(jstring_c, "true"))
			stop = 1;
		else
			stop = 0;
		log("libcurious: run_curiousdroid: stop = %d\n", stop)
		stopintent = stop;
		hold_print = 0;
		viewcalled++;
		return;
	}
	else if(type == 3) {
		log("About to define isRoot method\n")

		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, curract);
		
		jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/app/Activity"));

		mystring = reflect_call(env, curiousdroid, "checkRoot", sig, args);
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed calling isRoot.\n")
		}
		log("About to set root to value of isroot\n")

		if(strstr(jstring_c, "true"))
			isroot = 1;
		else
			isroot = 0;
		if(isroot)
			log("isroot = true -> %d\n", isroot)
		else
			log("isroot = flase -> %d\n", isroot)
		hold_print = 0;
		viewcalled++;
		(*env)->ReleaseStringUTFChars(env, mystring, jstring_c);
		return;
	}
	else {
		log("Called from onResume.\n")
		jvalue args[2];
		args[0].l = curiousdroid;
		args[1].l = (*env)->NewObjectArray(env, 2, (*env)->FindClass(env,"java/lang/Object"), 0);
		(*env)->SetObjectArrayElement(env, args[1].l, 0, seedview);
		(*env)->SetObjectArrayElement(env, args[1].l, 1, (*env)->NewStringUTF(env, "true"));
		
		jobjectArray sig = (*env)->NewObjectArray(env, 2,(*env)->FindClass(env, "java/lang/Class"), 0);
		(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));
		(*env)->SetObjectArrayElement(env, sig, 1, (*env)->FindClass(env,"java/lang/String"));

		mystring = reflect_call(env, curiousdroid, "expandChildViews", sig, args);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandChildViews method ID.\n")
		}
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem calling expanChildViews: mystring = %s\n", jstring_c)// mystring)
		
		(*env)->ReleaseStringUTFChars(env, mystring, jstring_c); 
		viewcalled++;
		hold_print = 0;
		return;
	}

	hold_print = 0;
	
	/*isrootactivity = "root";
	if(send(sock, isrootactivity, strlen(isrootactivity), 0) == -1) {
		log("Unable to send root event.\n")
	}*/
	if(send(sock, jstring_c, strlen(jstring_c), 0) == -1) {
		log("Unable to send event.\n")
	}
	else {
		log("Send complete.\n")
	}
	(*env)->ReleaseStringUTFChars(env, mystring, jstring_c); 

}

int startlistener() {
	if((sock = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
			log("Couldn't create a socket\n")
		}

		remote.sun_family = AF_UNIX;
		strcpy(remote.sun_path, "/data/local/tmp/eventsocket");
		len = strlen(remote.sun_path) + sizeof(remote.sun_family);
		if(connect(sock, (struct sockaddr *)&remote, len) == -1) {
			log("Unable to connect socket to listener\n")
			return -1;
		}

		return 0;
}
// END --- load class

// ---- don't need to modify ----

static int my_epoll_wait(int epfd, struct epoll_event *events, int maxevents, int timeout)
{
	int (*orig_epoll_wait)(int epfd, struct epoll_event *events, int maxevents, int timeout);
	srand(1013);
    orig_epoll_wait = (void*)eph.orig;

    hook_precall(&eph);

    dexstuff_resolv_dvm(&d);
    //
	do_patch_onresume();
	do_patch_alertdialog();
	do_patch_onfocuschange();
	do_patch_intentbroadcast();
	do_patch_telephony();
	do_patch_networking();
	do_patch_messaging();
    int res = orig_epoll_wait(epfd, events, maxevents, timeout);
   return res;
}

void my_init(void)
{
	log("%s started\n", __FILE__)
 
 	// for libbase
	set_logfunction(my_log);
	// for libdalvikhook
	dalvikhook_set_logfunction(my_log);

    hook(&eph, getpid(), "libc.", "epoll_wait", my_epoll_wait, 0);
}