#include <netinet/in.h>    
#include <stdio.h>    
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>    
#include <sys/types.h>    
#include <unistd.h>
#include <errno.h>


// from <linux/input.h>

struct input_event {
	struct timeval time;
	__u16 type;
	__u16 code;
	__s32 value;
};

#define EVIOCGVERSION		_IOR('E', 0x01, int)			/* get driver version */
#define EVIOCGID		_IOR('E', 0x02, struct input_id)	/* get device ID */
#define EVIOCGKEYCODE		_IOR('E', 0x04, int[2])			/* get keycode */
#define EVIOCSKEYCODE		_IOW('E', 0x04, int[2])			/* set keycode */

#define EVIOCGNAME(len)		_IOC(_IOC_READ, 'E', 0x06, len)		/* get device name */
#define EVIOCGPHYS(len)		_IOC(_IOC_READ, 'E', 0x07, len)		/* get physical location */
#define EVIOCGUNIQ(len)		_IOC(_IOC_READ, 'E', 0x08, len)		/* get unique identifier */

#define EVIOCGKEY(len)		_IOC(_IOC_READ, 'E', 0x18, len)		/* get global keystate */
#define EVIOCGLED(len)		_IOC(_IOC_READ, 'E', 0x19, len)		/* get all LEDs */
#define EVIOCGSND(len)		_IOC(_IOC_READ, 'E', 0x1a, len)		/* get all sounds status */
#define EVIOCGSW(len)		_IOC(_IOC_READ, 'E', 0x1b, len)		/* get all switch states */

#define EVIOCGBIT(ev,len)	_IOC(_IOC_READ, 'E', 0x20 + ev, len)	/* get event bits */
#define EVIOCGABS(abs)		_IOR('E', 0x40 + abs, struct input_absinfo)		/* get abs value/limits */
#define EVIOCSABS(abs)		_IOW('E', 0xc0 + abs, struct input_absinfo)		/* set abs value/limits */

#define EVIOCSFF		_IOC(_IOC_WRITE, 'E', 0x80, sizeof(struct ff_effect))	/* send a force effect to a force feedback device */
#define EVIOCRMFF		_IOW('E', 0x81, int)			/* Erase a force effect */
#define EVIOCGEFFECTS		_IOR('E', 0x84, int)			/* Report number of effects playable at the same time */

#define EVIOCGRAB		_IOW('E', 0x90, int)			/* Grab/Release device */

// end <linux/input.h>

#define BUFF_SIZE 512


int main(int argc, char* argv[]) {
	char buffer[BUFF_SIZE];
	int eventfd, readlen, t, version;
	unsigned int sock1, sock2;
	struct sockaddr_un local, remote;

	if((sock1 = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		fprintf(stderr, "Couldn't create socket.\n");
		return 1;
	}

	local.sun_family = AF_UNIX;
	strcpy(local.sun_path, "/data/local/tmp/eventsocket");
	unlink(local.sun_path);
	len = strlen(local.sun_path) + sizeof(local.sun_family);
	if((bind(sock1, (struct sockaddr *)&local, len)) == -1) {
		fprintf(stderr, "Couldn't bind socket to local address.\n");
		return 2;
	}

	if(listen(sock1, 5) == -1) {
		fprintf(stderr, "Couldn't listen on socket.\n");
		return 3;
	}

	if((eventfd = open("/dev/input/event2", O_RDWR)) < 0) {
		fprintf(stderr, "Couldn't open event driver.\n");
		return 2;
	}
	if (ioctl(eventfd, EVIOCGVERSION, &version)) {
        fprintf(stderr, "could not get driver version for /dev/input/event2, %s\n", strerror(errno));
        return 1;
    }

	/*if((fifofd = open("eventfifo", O_RDONLY)) != 0) {
		fprintf(stderr, "Couldn't opene the fifo.\n");
	}*/

	while(1) {
		int done, n, t_off, type, code, value, ret;
		struct input_event event;
		t = sizeof(remote);
		if((sock2 = accept(sock1, (struct sockaddr *)&remote, &t)) == -1) {
			fprintf(stderr, "couldn't accept connection.\n", );
			return 5;
		}

		do {
			n = recv(sock2, buffer, BUFF_SIZE, 0);
			if(n > 0) {
				sscanf(buffer, "%d %d %d %d", &t_off, &type, &code, &value);
				memset(&event, 0, sizeof(event));
			    event.type = type;
			    event.code = code;
			    event.value = value;
			    usleep(t_off);
			    ret = write(eventfd, &event, sizeof(event));
			    if(ret < sizeof(event)) {
			        fprintf(stderr, "write event failed, %s\n", strerror(errno));
			        return -1;
			    }
			}
		}while(n > 0);
		close(sock2);
	}
}
