#define _GNU_SOURCE
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <string.h>
#include <termios.h>
#include <pthread.h>
#include <sys/epoll.h>

#include <jni.h>
#include <stdlib.h>

#include "hook.h"
#include "dexstuff.h"
#include "dalvik_hook.h"
#include "base.h"
#include "log.h"

#undef log

#define log(...) \
        {FILE *fp = fopen("/data/local/tmp/log", "a+");\
        fprintf(fp, __VA_ARGS__);\
        fclose(fp);}

void __attribute__ ((constructor)) my_init(void);

static struct hook_t eph;
static struct dexstuff_t d;

static void my_log(char *msg)
{
	log(msg)
}

// START --- change stuff ---
static struct dalvik_hook_t sb1;

static void* sb1_tostring(JNIEnv *env, jobject obj)
{
	log("tostring\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)

	dalvik_prepare(&d, &sb1, env);
	void *res = (*env)->CallObjectMethod(env, obj, sb1.mid); 
	log("success calling : %s\n", sb1.method_name)
	dalvik_postcall(&d, &sb1);

	char *s = (*env)->GetStringUTFChars(env, res, 0);
	if (s) {
		log("sb1.toString() = %s\n", s)
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}

	return res;
}

void do_patch()
{
	// patch Method toString() in java.lang.StringBuffer to call sb1_tostring
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Ljava/lang/StringBuffer;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"toString", // method name
		"()Ljava/lang/String;", // method signature: (ARGUMENTS in L format)Return_value
		1, // paramter size = number of args + 1 (if method not static)
		sb1_tostring); // function to use for patch
	dalvik_hook(&d, &sb1);
}

// END --- change stuff ---

// START -- load class --- this will need to be adjusted ---

// global for the loaded class
void *my_cls;

// example
void* loadclass(JNIEnv *env)
{
    int i = dexstuff_loaddex(&d, "/data/local/tmp/classes.dex");
    log("loaddex res = %x\n", i)

	// load specific class form .dex file
    void *clazz = dexstuff_defineclass(&d, "org.mulliner.jnitest.smsbcast", i);
    log("my clazz = 0x%x\n", clazz)

    // load specifc class from .dex file inner classes are named via $
    // need to be done if class is required by main class
    void *clazz2 = dexstuff_defineclass(&d, "org.mulliner.jnitest.smsbcast$intentSender", i);
    log("my clazz2 = 0x%x\n", clazz)

    // find class, get a jclass object
    jclass tempClass2 = (*env)->FindClass(env, "org/mulliner/jnitest/smsbcast");
    log("tempClass2: 0x%x\n", tempClass2)
    tempClass2 = (*env)->NewGlobalRef(env, tempClass2);

    // find the constructor by signature
    jmethodID jmid = (*env)->GetMethodID(env, tempClass2, "<init>", "(Landroid/app/Service;)V");
    log("jmid = 0x%x\n", jmid)

    // call constructor
    my_cls = (*env)->NewObject(env, tempClass2, jmid, NULL); // NULL is just to make it compile this should be a object
    log("completed 0x%x\n", my_cls)
    
    // alloc global reference
    my_cls = (*env)->NewGlobalRef(env, my_cls);
    log("global 0x%x\n", my_cls)
}

// using jni http://docs.oracle.com/javase/1.4.2/docs/guide/jni/spec/functions.html

// example
void call_stuff(JNIEnv *env)
{
	// find class - the one we loaded!
    jclass tempClass2 = (*env)->FindClass(env, "org/mulliner/jnitest/smsbcast");
    log("tempClass2: 0x%x\n", tempClass2)
    
    // get the method by name and signature
    jmethodID jmid = (*env)->GetMethodID(env, tempClass2, "handleReq", "(Landroid/os/Bundle;I)Landroid/os/Bundle;");
    log("jmid handleReq = 0x%x\n", jmid)

    // prepare arguments
    // see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
    jvalue margs[2];
    margs[0].l = NULL;
    margs[1].i = 0;

    // needs to be adapted deppending on the class/method
    // using jni http://docs.oracle.com/javase/1.4.2/docs/guide/jni/spec/functions.html
    void *mres = (*env)->CallObjectMethodA(env, my_cls, jmid, margs);
    
    log("mres = 0x%x\n", mres)
}

// END --- load class

// ---- don't need to modify ----

static int my_epoll_wait(int epfd, struct epoll_event *events, int maxevents, int timeout)
{
	int (*orig_epoll_wait)(int epfd, struct epoll_event *events, int maxevents, int timeout);

    orig_epoll_wait = (void*)eph.orig;

    hook_precall(&eph);

    dexstuff_resolv_dvm(&d);
    do_patch();
            
    int res = orig_epoll_wait(epfd, events, maxevents, timeout);
        
   return res;
}

void my_init(void)
{
	log("%s started\n", __FILE__)
 
 	// for libbase
	set_logfunction(my_log);
	// for libdalvikhook
	dalvikhook_set_logfunction(my_log);

    hook(&eph, getpid(), "libc.", "epoll_wait", my_epoll_wait, 0);
}