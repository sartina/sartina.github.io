#define _GNU_SOURCE
#include <stdio.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <string.h>
#include <termios.h>
#include <sys/epoll.h>
#include <sys/time.h>

#include <jni.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdint.h>

#include "hook.h"
#include "dexstuff.h"
#include "dalvik_hook.h"
#include "base.h"
#include "log.h"

#undef log
#define log(...) \
        {FILE *fp = fopen("/data/local/tmp/log", "a+");\
        fprintf(fp, __VA_ARGS__);\
        fclose(fp);}

void __attribute__ ((constructor)) my_init(void);

static struct hook_t eph;
static struct dexstuff_t d;

static void my_log(char *msg)
{
	log(msg)
}

// START --- change stuff ---
static struct dalvik_hook_t sb0;
static struct dalvik_hook_t sb1;
static struct dalvik_hook_t sb2;
static struct dalvik_hook_t sb3;
static struct dalvik_hook_t sb4;
static struct dalvik_hook_t sb5;
static struct dalvik_hook_t sb6;
static struct dalvik_hook_t sb7;
static struct dalvik_hook_t sb8;
static struct dalvik_hook_t sb9;
static struct dalvik_hook_t sb10;
static struct dalvik_hook_t sb11;
static struct dalvik_hook_t sb12;
static struct dalvik_hook_t sb13;
static struct dalvik_hook_t sb14;
static struct dalvik_hook_t sb15;
static struct dalvik_hook_t sb16;
static struct dalvik_hook_t sb17;
static struct dalvik_hook_t sb18;
static struct dalvik_hook_t sb19;
static struct dalvik_hook_t sb20;
static struct dalvik_hook_t sb21;
static struct dalvik_hook_t sb22;
static struct dalvik_hook_t sb23;
static struct dalvik_hook_t sb24;
static struct dalvik_hook_t sb25;
static struct dalvik_hook_t sb26;
static struct dalvik_hook_t sb27;
static struct dalvik_hook_t sb28;
static struct dalvik_hook_t sb29;
static struct dalvik_hook_t sb30;
static struct dalvik_hook_t sb31;
static struct dalvik_hook_t sb32;
static struct dalvik_hook_t sb33;
static struct dalvik_hook_t sb34;
static struct dalvik_hook_t sb35;
static struct dalvik_hook_t sb36;
static struct dalvik_hook_t sb37;
static struct dalvik_hook_t sb38;
static struct dalvik_hook_t sb39;
static struct dalvik_hook_t sb40;
static struct dalvik_hook_t sb41;
static struct dalvik_hook_t sb42;
static struct dalvik_hook_t sb43;
static struct dalvik_hook_t sb44;
static struct dalvik_hook_t sb45;
static struct dalvik_hook_t sb46;
static struct dalvik_hook_t sb47;
static struct dalvik_hook_t sb48;
static struct dalvik_hook_t sb49;
static struct dalvik_hook_t sb50;
static struct dalvik_hook_t sb51;
static struct dalvik_hook_t sb52;
static struct dalvik_hook_t sb53;
static struct dalvik_hook_t sb54;
static struct dalvik_hook_t sb55;
static struct dalvik_hook_t sb56;
static struct dalvik_hook_t sb57;

void* loadclass(JNIEnv *env);
void* run_curiousdroid(JNIEnv *env, int type, int r);
void call_stuff(JNIEnv *env);

int startup = 1;
int viewcalled = 0;
int hold_print = 0;
jobject seedview, seeddialog,  seedintent, curract;
jboolean stopintent, isroot, isrootactivity;
// global for the loaded class
void *cdroid;
jobject viewlist;
void* viewnodecls;
void* cdroid_class;
//uint8_t root;
time_t curtime;
struct timeval t;

/*static void //gencoverage() {
	system("am broadcast -a edu.gatech.m3.emma.COLLECT_COVERAGE");
}*/


void* reflect_call(JNIEnv *env, jobject obj, char *name, void* sig, jvalue *args)
{
	jclass cl = (*env)->FindClass(env, "java/lang/Class");
	jmethodID mid = (*env)->GetMethodID(env, cl, "getMethod","(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;");
	
	jmethodID mid2 = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid2)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid2, 0);
	log("obj2 = %#x\n", obj2)
	
	jvalue args1[5];
	args1[0].l = (*env)->NewStringUTF(env, name);
	args1[1].l = sig;
	jobject obj3 = (*env)->CallObjectMethodA(env, obj2, mid, args1);
	log("getMethod = %#x\n", obj3)
	
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	mid = (*env)->GetMethodID(env, cl, "invoke","(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;");
	log("invoke mid = %#x\n", mid)
	args[0].l = obj;
	jobject obj4 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("obj4 = %#x\n", obj4)
	
	return obj4;
}

jobject loadclass_a23(JNIEnv *env, jobject obj, char *dexfile, char *dexclass, char *outerclass)
{
	// init dexclassloader
	jclass clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	jstring dp = (*env)->NewStringUTF(env, dexfile);
	jstring out = (*env)->NewStringUTF(env, "/data/local/tmp/cache");
	
	// get classloader from outerclass
	jclass cl = (*env)->FindClass(env, outerclass);
	log("cl = %#x\n", cl)
	jmethodID mid = (*env)->GetMethodID(env, cl, "getClass","()Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jobject obj2 = (*env)->CallObjectMethodA(env, obj, mid, 0);
	log("obj2 = %#x\n", obj2)
	cl = (*env)->FindClass(env, "java/lang/Class");
	log("cl =- %#x\n", cl)
	mid = (*env)->GetMethodID(env, cl, "getClassLoader","()Ljava/lang/ClassLoader;");
	log("mid = %#x\n", mid)
	
	
	// create instance of dexclassloader
	obj2 = (*env)->CallObjectMethodA(env, obj2, mid, 0);
	log("classloder = %#x\n", obj2)	

	// create instance of newly loaded class			
	jobject obj3 = 0;
	jmethodID constructor = (*env)->GetMethodID(env, clc, "<init>","(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/ClassLoader;)V");
	if (constructor) {
		jvalue args[4];
		args[0].l = dp;
		args[1].l = out;
		args[2].l = 0;
		args[3].l = obj2;

		obj3 = (*env)->NewObjectA(env, clc, constructor, args);
		log("new class loader: new obj = 0x%x\n", obj3)
		
		if (!obj3)
			log("failed to create class loader, FATAL!\n")
	}
	else {
		log("constructor == 0\n")
	}
	
	// load class using dexclassloader
	clc = (*env)->FindClass(env, "dalvik/system/DexClassLoader");
	log("class loader = %#x\n", clc);
	mid = (*env)->GetMethodID(env, clc, "loadClass","(Ljava/lang/String;)Ljava/lang/Class;");
	log("mid = %#x\n", mid)
	jvalue args[1];
	args[0].l = (*env)->NewStringUTF(env, dexclass);
	obj2 = (*env)->CallObjectMethodA(env, obj3, mid, args);
	log("loaded = %#x\n", obj2)
	
	// new instance of newly loaded class
	cl = (*env)->FindClass(env, "java/lang/Class");
	mid = (*env)->GetMethodID(env, cl, "newInstance", "()Ljava/lang/Object;");
	log("newinstance mid = %#x\n", mid)
	jobject obj4 = (*env)->CallObjectMethodA(env, obj2, mid, args);
	log("instance = %#x\n", obj4)
	
	
	return (*env)->NewGlobalRef(env, obj4);
	
	/*
	cl = (*env)->FindClass(env, "java/lang/Class");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	cl = (*env)->FindClass(env, "java/lang/reflect/Method");
	d.dvmDumpClass_fnPtr(cl, (void*)1);
	*/
}

static void printString(JNIEnv *env, jobject str, char *l, int r)
{
	//struct timeval t;
	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {//} && !hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: %s%s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, l, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
}

static void* sb0_onresume(JNIEnv *env, jobject obj) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb0_onresume BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_prepare(&d, &sb0, env);
	(*env)->CallVoidMethod(env, obj, sb0.mid, NULL); 
	if(startup) {
		jclass act = (*env)->FindClass(env, "android/app/Activity");

		jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("GetMethodID-getWindow did not work.\n")
		log("jmid_win = 0x%x\n", jmid_win)

		jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("getWindow() did not work.\n")
		log("window = 0x%x\n", window)

		jclass win       = (*env)->FindClass(env, "android/view/Window");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("FindClass-Window did not work.\n")

		jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("getMethodID-getDecorView did not work.\n")
		log("jmid_view = 0x%x\n", jmid_view)

		jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("CallObjectMethod-getDecorView did not work.\n")
		log("view = 0x%x\n", view)

		seedview = (*env)->NewGlobalRef(env, view);
		run_curiousdroid(env, obj, 1000, r);
		startup = 0;
	}
	dalvik_postcall(&d, &sb0);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb0_onresume END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("\n")
	//gencoverage();
	return;
}

static void* onwindowfocuschanged(JNIEnv *env,  jobject obj, jboolean hasfocus) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: onwindowfocuschanged BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	/*log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	*/
	dalvik_prepare(&d, &sb1, env);
	(*env)->CallVoidMethod(env, obj, sb1.mid, hasfocus);
	uint8_t focus = (uint8_t)hasfocus;

	if(focus) {
		jclass act = (*env)->FindClass(env, "android/app/Activity");
		jclass fragManImp = (*env)->FindClass(env, "android/app/FragmentManagerImpl");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem finding FragmentManagerImpl class.\n")
		else
			log("fragManImp = 0x%x\n", fragManImp)

		jfieldID mFragments = (*env)->GetFieldID(env, act, "mFragments", "Landroid/app/FragmentManagerImpl;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem getting mFragments field.\n")
		else
			log("mFragments = 0x%x\n", mFragments)

		jobject managerImpl = (*env)->GetObjectField(env, obj, mFragments);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem getting mFragments object.\n")
		else
			log("managerImpl = 0x%x\n", managerImpl)

		jfieldID mAdded = (*env)->GetFieldID(env, fragManImp, "mAdded", "Ljava/util/ArrayList;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem getting mAdded field.\n")
	//	else
			//log("mAdded = 0x%x\n", mAdded)

		jobject addedFrags = (*env)->GetObjectField(env, managerImpl, mAdded);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem getting addedFrags object.\n")
	//	else
			//log("addedFrags = 0x%x\n", addedFrags)

		jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
		//log("jmid_win = 0x%x\n", jmid_win)
		jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
		//log("window = 0x%x\n", window)
		jclass win       = (*env)->FindClass(env, "android/view/Window");
		jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
		//log("jmid_view = 0x%x\n", jmid_view)
		jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
		//log("view = 0x%x\n", view)
		//jmid_act = (*env)->GetMethodID(env, act, "isTaskRoot", "()Z");
		//isrootactivity = (*env)->CallBooleanMethod(env, obj, jmid_act);
		seedview = (*env)->NewGlobalRef(env, view);
		//gencoverage();
		run_curiousdroid(env, 0, r);
	}
	
	dalvik_postcall(&d, &sb1);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: onwindowfocuschanged END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("\n")
	return;
}

static void* ondialog(JNIEnv *env,  jobject obj, jboolean hasfocus) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: ondialog BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//log("env = 0x%x\n", env)
	//log("obj = 0x%x\n", obj)

	dalvik_prepare(&d, &sb2, env);
	(*env)->CallVoidMethod(env, obj, sb2.mid, hasfocus); 
	uint8_t focus = (uint8_t)hasfocus;

	if(focus) {
		jclass dialog = (*env)->FindClass(env, "android/app/Dialog");
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem finding Dialog class.\n")
		log("dialog = 0x%x\n", dialog)

		jfieldID mDecor = (*env)->GetFieldID(env, dialog, "mDecor", "Landroid/view/View;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Could not get fieldID mDecor\n")
		log("mDecor = 0x%x\n", mDecor)

		jobject view = (*env)->GetObjectField(env, obj, mDecor);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Could not get field object view.\n")
		log("view = 0x%x\n", view)
		seedview = (*env)->NewGlobalRef(env, view);
		//gencoverage();
		run_curiousdroid(env, 1, r);
	}
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: success calling : Dialog.%s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, sb2.method_name)
	
	dalvik_postcall(&d, &sb2);
	log("\n")
}

static void* onFragmentManager(JNIEnv *env, jobject obj) {
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: onFragmentManager\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec)
	//log("Landroid/app/FragmentManagerImpl is hookable!!!\n")
	dalvik_prepare(&d, &sb3, env);
	(*env)->CallVoidMethod(env, obj, sb3.mid, NULL); 
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: success calling : %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, sb3.method_name)
	
	dalvik_postcall(&d, &sb3);
	log("\n")
}

static void* onFragment(JNIEnv *env, jobject obj) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: onFragment\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	jclass frag = (*env)->FindClass(env, "android/app/Fragment");
	jthrowable exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem finding Fragment class.\n")
	log("frag = 0x%x\n", frag)

	jmethodID jmid_getact = (*env)->GetMethodID(env, frag, "getActivity", "()V");
	exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem finding getActivity method from Fragment class.\n")
	log("jmid_getact = 0x%x\n", jmid_getact)

	jobject act_obj = (*env)->CallObjectMethod(env, obj, jmid_getact);
	exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem getting Activity object from Fragment.\n")
	log("act_obj = 0x%x\n", act_obj)

	jclass act = (*env)->FindClass(env, "android/app/Activity");
	exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem finding Activity class.\n")
	log("act = 0x%x\n", act)

	jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
	log("jmid_win = 0x%x\n", jmid_win)
	jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
	log("window = 0x%x\n", window)
	jclass win       = (*env)->FindClass(env, "android/view/Window");
	jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
	log("jmid_view = 0x%x\n", jmid_view)
	jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
	log("view = 0x%x\n", view)
	seedview = (*env)->NewGlobalRef(env, view);
	run_curiousdroid(env, 0, r);


	dalvik_prepare(&d, &sb3, env);
	(*env)->CallVoidMethod(env, obj, sb3.mid, NULL); 
	log("success calling : %s\n", sb3.method_name)
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: success calling : Dialog.%s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, sb2.method_name)
	
	dalvik_postcall(&d, &sb3);
	log("\n")
}

static void* onFragmentTransaction(JNIEnv *env, jobject obj, jobject frag) {
	int r = rand();
	//struct timeval t;
	log("onFragmentTransaction\n")
	//log("env = 0x%x\n", env)
	//log("obj = 0x%x\n", obj)
	//log("frag = 0x%x\n", frag)

	jclass frag_class = (*env)->FindClass(env, "android/app/Fragment");
	jthrowable exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem finding Fragment  class.\n")
	log("frag_class = 0x%x\n", frag_class)

	jmethodID jmid_getact = (*env)->GetMethodID(env, frag_class, "getActivity", "()V");
	exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem finding getActivity method from Fragment class.\n")
	log("jmid_getact = 0x%x\n", jmid_getact)

	jobject act_obj = (*env)->CallObjectMethod(env, frag, jmid_getact);
	exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem getting Activity object from Fragment.\n")
	log("act_obj = 0x%x\n", act_obj)

	jclass act = (*env)->FindClass(env, "android/app/Activity");
	exc = (*env)->ExceptionOccurred(env);
	if(exc)
		log("Problem finding Activity class.\n")
	log("act = 0x%x\n", act)

	jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
	log("jmid_win = 0x%x\n", jmid_win)
	jobject window      = (*env)->CallObjectMethod(env, frag, jmid_win);
	log("window = 0x%x\n", window)
	jclass win       = (*env)->FindClass(env, "android/view/Window");
	jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
	log("jmid_view = 0x%x\n", jmid_view)
	jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
	log("view = 0x%x\n", view)
	seedview = (*env)->NewGlobalRef(env, view);
	run_curiousdroid(env, 0, r);


	dalvik_prepare(&d, &sb3, env);
	(*env)->CallVoidMethod(env, obj, sb3.mid); 
	log("success calling : %s\n", sb3.method_name)
	
	dalvik_postcall(&d, &sb3);
	log("\n")
}


static void* sb4_tostring(JNIEnv *env, jobject obj)
{
	//struct timeval t;
	int r = rand();
	////if(!hold_print) {
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb4_tostring BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	/*log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
*/

	dalvik_prepare(&d, &sb4, env);
	void *res = (*env)->CallObjectMethod(env, obj, sb4.mid); 
	//log("success calling : %s\n", sb1.method_name)
	

	char *s = (*env)->GetStringUTFChars(env, res, 0);
	if (s ){//&& !hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: String = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	
	dalvik_postcall(&d, &sb4);
	////if(!hold_print) {
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb4_tostring END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}


// needs locking
/*static void* sb22_init(JNIEnv *env, jobject obj, jobject str)
{
/*	log("sb22_tostring_init\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)

	printString(env, str, "sb22 = ");

	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb22, env);
	(*env)->CallVoidMethodA(env, obj, sb22.mid, args);
	//log("success calling : %s\n", sb22.method_name)
	dalvik_postcall(&d, &sb22);

	//return res;
}*/

static void* sb5_tostring(JNIEnv *env, jobject obj)
{
	//struct timeval t;
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%D: sb5_tostring BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_prepare(&d, &sb5, env);
	void *res = (*env)->CallObjectMethod(env, obj, sb5.mid); 
	//log("success calling : %s\n", sb20.method_name)
	

	char *s = (*env)->GetStringUTFChars(env, res, 0);
	if (s) {//} && !hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: String() = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	
	dalvik_postcall(&d, &sb5);
	////if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb5_tostring END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb8_get(JNIEnv *env, jobject obj, jint i)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb8_get BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
*/

	jvalue args[1];
	args[0].i = i;
	dalvik_prepare(&d, &sb8, env);
	void *res = (*env)->CallByteMethodA(env, obj, sb8.mid, args); 
	//log("success calling : %s\n", sb24.method_name)
	
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb8.get(%d) = %x\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, i, r, res)
	//}
	dalvik_postcall(&d, &sb8);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb8_get END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb10_getint(JNIEnv *env, jobject obj, jint i)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb10_getint BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
*/

	jvalue args[1];
	args[0].i = i;
	dalvik_prepare(&d, &sb10, env);
	void *res = (*env)->CallIntMethodA(env, obj, sb10.mid, args); 
	//log("success calling : %s\n", sb26.method_name)
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb10.getInt(%d) = %d\n",(unsigned long)t.tv_sec, (unsigned long)t.tv_usec, i, r, res)
	//}
	dalvik_postcall(&d, &sb10);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb10_getint END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb9_get(JNIEnv *env, jobject obj)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print){
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb9_get BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
*/

	dalvik_prepare(&d, &sb9, env);
	void *res = (*env)->CallByteMethod(env, obj, sb9.mid); 
	//log("success calling : %s\n", sb25.method_name)
	

	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb9.get() = %x\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res)
	//}
	dalvik_postcall(&d, &sb9);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb9_get END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

/*static void* sb21_getbytes(JNIEnv *env, jobject obj)
{/*
	log("tostring\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)


	dalvik_prepare(&d, &sb21, env);
	void *res = (*env)->CallObjectMethod(env, obj, sb21.mid); 
	//log("success calling : %s\n", sb21.method_name)
	dalvik_postcall(&d, &sb21);

	printString(env, obj, "sb21 = "); 

	return res;
}*/

static void* sb6_compareto(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();

	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb6_compareto BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb6, env);
	int res = (*env)->CallIntMethodA(env, obj, sb6.mid, args); 
	
	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {//} && !hold_print) {
		printString(env, obj, "sb6 = ", r); 
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb6.comapreTo() = %d s> %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb6);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb6_compareto END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb7_compareto(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb7_compareto BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb7, env);
	int res = (*env)->CallIntMethodA(env, obj, sb7.mid, args); 
	
	//if(!hold_print) {
		printString(env, obj, "sb7 = ", r);
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb7.compareTo() = %d\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res)
	//}
	dalvik_postcall(&d, &sb7);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb7_compareto END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb11_comparetocase(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb11_comparetocase BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb11, env);
	int res = (*env)->CallIntMethodA(env, obj, sb11.mid, args); 
	//log("success calling : %s\n", sb3.method_name)
	
	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb11 = ", r); 
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb11.comapreToIgnoreCase() = %d s> %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb11);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb11_comparecase END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb15_indexof(JNIEnv *env, jobject obj, jobject str, jint i)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb15_indexof BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[2];
	args[0].l = str;
	args[1].i = i;
	dalvik_prepare(&d, &sb15, env);
	int res = (*env)->CallIntMethodA(env, obj, sb15.mid, args);
	//log("success calling : %s\n", sb7.method_name)

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb15 = ", r); 
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb15.indexOf() = %d (i=%d) %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, i, s)
		//}
	
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb15);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb15_indexof END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb16_indexof(JNIEnv *env, jobject obj, jobject str, jint i)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb16_indexof BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
//	}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[2];
	args[0].l = str;
	args[1].i = i;
	dalvik_prepare(&d, &sb16, env);
	int res = (*env)->CallIntMethodA(env, obj, sb16.mid, args);
	//log("success calling : %s\n", sb11.method_name) 

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb16 = ", r);
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb16.indexOf() = %d (i=%d) %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, i, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb16);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb16_indexof END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

/*static void* sb19_indexof(JNIEnv *env, jobject obj, jobject str, jint i)
{

	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb19_indexof\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec)
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)

	jvalue args[2];
	args[0].l = str;
	args[1].i = i;
	dalvik_prepare(&d, &sb19, env);
	int res = (*env)->CallIntMethodA(env, obj, sb19.mid, args);
	//log("success calling : %s\n", sb19.method_name)
	dalvik_postcall(&d, &sb19);

	printString(env, obj, "sb19 = "); 

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb19.indexOf() = %d (i=%d) %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, res, i, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}

	return res;
}*/

static void* sb18_startswith(JNIEnv *env, jobject obj, jobject str, jint i)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb18_startswith BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[2];
	args[0].l = str;
	args[1].i = i;
	dalvik_prepare(&d, &sb18, env);
	int res = (*env)->CallBooleanMethodA(env, obj, sb18.mid, args);
	//log("success calling : %s\n", sb10.method_name)

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb18 = ", r);
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb18.startswith() = %d (i=%d) %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, i, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb18);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb18_startswith END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	log("\n")
	return res;
}

static void* sb19_matches(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb19_matches BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb19, env);
	int res = (*env)->CallBooleanMethodA(env, obj, sb19.mid, args);
	//log("success calling : %s\n", sb8.method_name)

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb19 = ", r); 
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb19.matches() = %d %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb19);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb19_matches END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb12_equalsIgnoreCase(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print)  {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb12_equalsIgnoreCase BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb12, env);
	int res = (*env)->CallBooleanMethodA(env, obj, sb12.mid, args);
	//log("success calling : %s\n", sb13.method_name)

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb12 = ", r);
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb12.equalsIgnoreCase() = %d %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb12);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb12_equalsIgnoreCase END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb16_equals(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb16_equals BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb16, env);
	int res = (*env)->CallBooleanMethodA(env, obj, sb16.mid, args);
	//log("success calling : %s\n", sb16.method_name)
	
	//if(!hold_print) {
		printString(env, obj, "sb16 = ", r);
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: equals end", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r);
	//}
	// 
/*
	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		log("sb13.equalsIgnoreCase() = %d %s\n", res, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
*/	dalvik_postcall(&d, &sb16);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb16_equals END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb14_contentEquals(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb14_contentequals BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb14, env);
	int res = (*env)->CallBooleanMethodA(env, obj, sb14.mid, args);
	//log("success calling : %s\n", sb14.method_name)

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb14 = ", r); 
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb14.contentEquals() = %d %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb14);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb14_contentequals END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb17_endswith(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb17_endswith BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb17, env);
	int res = (*env)->CallBooleanMethodA(env, obj, sb17.mid, args);
	//log("success calling : %s\n", sb9.method_name)

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb17 = ", r); 
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb17.endswith() = %d %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb17);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb17_endswith END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb13_contains(JNIEnv *env, jobject obj, jobject str)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb13_contains BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
/*	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
*/
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb13, env);
	int res = (*env)->CallBooleanMethodA(env, obj, sb13.mid, args);
	//log("success calling : %s\n", sb6.method_name)

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		//if(!hold_print) {
			printString(env, obj, "sb13 = ", r); 
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb13.contains() = %d %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res, s)
		//
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb13);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb13_contains END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

/*static void* sb4_append(JNIEnv *env, jobject obj, jobject str)
{
	/*
	log("append\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
	*
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb4, env);
	void *res = (*env)->CallObjectMethodA(env, obj, sb4.mid, args); 
	//log("success calling : %s\n", sb4.method_name)
	dalvik_postcall(&d, &sb4);

	printString(env, obj, "sb4 = "); 

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		char *s1 = (*env)->GetStringUTFChars(env, res, 0);
		log("sb4.append = %s s> %s\n", s1, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
		(*env)->ReleaseStringUTFChars(env, res, s1);
	}

	return res;
}

static void* sb15_append(JNIEnv *env, jobject obj, jobject str)
{
	/*
	log("append\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
	*
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb15, env);
	void *res = (*env)->CallObjectMethodA(env, obj, sb15.mid, args); 
	//log("success calling : %s\n", sb15.method_name)
	dalvik_postcall(&d, &sb15);

	printString(env, obj, "sb15 = "); 

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		char *s1 = (*env)->GetStringUTFChars(env, res, 0);
		log("sb15.append = %s s> %s\n", s1, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
		(*env)->ReleaseStringUTFChars(env, res, s1);
	}

	return res;
}

static void* sb12_append(JNIEnv *env, jobject obj, jobject str)
{
	/*
	log("append\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
	*
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb12, env);
	void *res = (*env)->CallObjectMethodA(env, obj, sb12.mid, args); 
	//log("success calling : %s\n", sb12.method_name)
	dalvik_postcall(&d, &sb12);

	printString(env, obj, "sb12 = "); 

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		char *s1 = (*env)->GetStringUTFChars(env, res, 0);
		log("sb12.append = %s s> %s\n", s1, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
		(*env)->ReleaseStringUTFChars(env, res, s1);
	}

	return res;
}

static void* sb17_append(JNIEnv *env, jobject obj, jobject str)
{
	/*
	log("append\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
	*
	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb17, env);
	void *res = (*env)->CallObjectMethodA(env, obj, sb17.mid, args); 
	//log("success calling : %s\n", sb17.method_name)
	dalvik_postcall(&d, &sb17);

	printString(env, obj, "sb17 = "); 

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		char *s1 = (*env)->GetStringUTFChars(env, res, 0);
		log("sb17.append = %s s> %s\n", s1, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
		(*env)->ReleaseStringUTFChars(env, res, s1);
	}

	return res;
}

static void* sb18_append(JNIEnv *env, jobject obj, jobject str)
{
	/*
	log("append\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
	*

	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb18, env);
	void *res = (*env)->CallObjectMethodA(env, obj, sb18.mid, args); 
	//log("success calling : %s\n", sb18.method_name)
	dalvik_postcall(&d, &sb18);

	printString(env, obj, "sb18 = "); 

	char *s = (*env)->GetStringUTFChars(env, str, 0);
	if (s) {
		char *s1 = (*env)->GetStringUTFChars(env, res, 0);
		log("sb18.append = %s s> %s\n", s1, s)
		(*env)->ReleaseStringUTFChars(env, str, s); 
		(*env)->ReleaseStringUTFChars(env, res, s1);
	}

	return res;
}*/

static void* sb20_getmethod(JNIEnv *env, jobject obj, jobject str, jobject cls)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb20_getmethod BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	/*log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
	log("cls = 0x%x\n", cls)
	*/

	jvalue args[2];
	args[0].l = str;
	args[1].l = cls;
	dalvik_prepare(&d, &sb20, env);
	void *res = (*env)->CallObjectMethodA(env, obj, sb20.mid, args); 
	//log("success calling : %s\n", sb20.method_name)
	

	if (str) {
		char *s = (*env)->GetStringUTFChars(env, str, 0);
		if (s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb20.getmethod = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, str, s);
	}
	dalvik_postcall(&d, &sb20);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb20_getmethod END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb21_getmethods(JNIEnv *env, jobject obj)
{
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb21_getmethods BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	/*log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	log("str = 0x%x\n", str)
	log("cls = 0x%x\n", cls)
	*/

	//jvalue args[2];
	//args[0].l = str;
	//args[1].l = cls;
	dalvik_prepare(&d, &sb21, env);
	void *res = (*env)->CallObjectMethod(env, obj, sb21.mid, NULL); 
	//log("success calling : %s\n", sb20.method_name)
	jobject str;
	if (str) {
		char *s = (*env)->GetStringUTFChars(env, str, 0);
		//if (s) {
			//if(!hold_print)
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb21.getmethod = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, s)
		//}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb21);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb21_getmethods END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb22_getname(JNIEnv *env, jobject obj)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb22_getname BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	dalvik_prepare(&d, &sb22, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb22.mid, NULL); 
	//log("success calling : %s\n", sb20.method_name)
	

	if (res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if (s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb22.getname() = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb22);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb22_getname END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}


static void* sb23_getsimplename(JNIEnv *env, jobject obj)
{
	//struct timeval t;
	int r = rand();
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb23_getsimplename BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	dalvik_prepare(&d, &sb23, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb23.mid, NULL); 
	//log("success calling : %s\n", sb20.method_name)
	

	if (res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if (s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb23.getsimplename = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb23);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb23_getsimplename END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb24_tostring(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb24_tostring BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//

	dalvik_prepare(&d, &sb24, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb24.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb24.tostring = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb24);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb24_tostring END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb25_isfrommockprovider(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb25_isfrommockprovider BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb25, env);
	jboolean res = (*env)->CallObjectMethod(env, obj, sb25.mid, NULL);

	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb25.isfrommockprovider = %d\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, res)
	//}

	dalvik_postcall(&d, &sb25);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb25_isfrommockprovider END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb26_convert(JNIEnv *env, jobject obj, jobject str) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb26_convert BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb26, env);
	jint res = (*env)->CallIntMethodA(env, obj, sb26.mid, args);

	if(str) {
		char *s = (*env)->GetStringUTFChars(env, str, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb26.convert = %s, to %d\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s, res)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb26);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb26_convert END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb27_toString(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb27_toString BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb27, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb27.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb27.tostring = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb27);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb27_tostring END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb28_getphone(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb28_getphone BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb28, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb28.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb28.getphones = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
			(*env)->ReleaseStringUTFChars(env, res, s); 
		}
	}
	dalvik_postcall(&d, &sb28);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb28_getphone END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb29_sendtextmessage(JNIEnv *env, jobject obj, jobject str) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb29_sendtextmessage BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	jvalue args[1];
	args[0].l = str;
	dalvik_prepare(&d, &sb29, env);
	(*env)->CallVoidMethodA(env, obj, sb29.mid, args);

	if(str) {
		char *s = (*env)->GetStringUTFChars(env, str, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb29.sendtextmessage = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, str, s); 
	}
	dalvik_postcall(&d, &sb29);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb29_sendtextmessage END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb30_senddatamessage(JNIEnv *env, jobject obj, jobject str1, jobject str2, jshort port,
	jbyteArray data, jobject sintent, jobject dintent) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb30_senddatamessage BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	/*jvalue args[6];
	args[0].l = str1;
	args[1].l = str2;
	args[2].s = port;
	args[3].b = &data;
	args[4].l = sintent;
	args[5].l = dintent;*/

	dalvik_prepare(&d, &sb30, env);
	(*env)->CallVoidMethod(env, obj, sb30.mid, str1, str2, port, data, sintent, dintent);

	if(str1 && str2) {
		//if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb30.senddatamessage => destAddr: %s, SrcAddr: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, str1, str2)
		//}
	}
	(*env)->ReleaseStringUTFChars(env, str1, str2); 
	dalvik_postcall(&d, &sb30);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb30_senddatamessage END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb31_getmessagebody(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb31_getmessagebody BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb31, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb31.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb31.getmessagebody = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb31);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb31_getsimplename END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb32_getorigiatingaddress(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb32_getorigiatingaddress BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb32, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb32.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb32.getoriginatingaddress = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
			(*env)->ReleaseStringUTFChars(env, res, s);
		}
	}
	 
	dalvik_postcall(&d, &sb32);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb32_getorigiatingaddress END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb33_getservicecenteraddress(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb33_getservicecenteraddress BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb33, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb33.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb33.getservicecenteraddress = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			//}
		}
		(*env)->ReleaseStringUTFChars(env, res, s); 
	}
	dalvik_postcall(&d, &sb33);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb33_getservicecenteraddress END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb34_execute(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb34_execute BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
//	}

	dalvik_prepare(&d, &sb34, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb34.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb34.execute = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
		//	}
			(*env)->ReleaseStringUTFChars(env, res, s); 
		}
	}
	
	dalvik_postcall(&d, &sb34);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb34_execute END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb35_fromparts(JNIEnv *env, jobject obj, jobject str1, jobject str2, jobject str3) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb35_fromparts BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb35, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb35.mid, str1, str2, str3);

	if(str1 || str2 || str3) {
		//if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb35.fromparts => scheme: %s, ssp: %s, fragment: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, str1, str2, str3)
		//}
	}
	dalvik_postcall(&d, &sb35);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb35_fromparts END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb36_withappendedpaths(JNIEnv *env, jobject obj, jobject uri, jobject str) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb36_withappendedpaths BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb36, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb36.mid, uri, str);

	if(str) {
		//if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb36.withAppendedPaths => pathsegment: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, str)
		//}
	}
	dalvik_postcall(&d, &sb36);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb36_withappendedpaths END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;
}

static void* sb37_tostring(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	//if(1) {//!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb37_tostring BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb37, env);
	void* res = (*env)->CallObjectMethod(env, obj, sb37.mid, NULL);

	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		if(s) {
			if(1) {//!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb37.tostring = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			}
			(*env)->ReleaseStringUTFChars(env, res, s);
		}
	}
	 
	dalvik_postcall(&d, &sb37);
	if(1) {//!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb37_tostring END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	}
	return res;
}

static void* sb38_onReceive(JNIEnv *env, jobject obj, jobject ctx, jobject intent) {
	int r = rand();
	//struct timeval t;
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb38_onReceive BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}

	dalvik_prepare(&d, &sb38, env);
	(*env)->CallVoidMethod(env, obj, sb38.mid, ctx, intent);

	/*if(str) {
		char *s = (*env)->GetStringUTFChars(env, str, 0);
		if(s) {
			//if(!hold_print) {
				gettimeofday(&t, NULL);
				log("libcurious: %lu%lu-%d: sb29.sendtextmessage = %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
			}
		}
	}*/
	dalvik_postcall(&d, &sb38);
	//if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb38 END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return;
}

static void* sb39_registerreceiver(JNIEnv *env, jobject obj, jobject bcastrec, jobject intfliter) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb39_registerreceiver BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_prepare(&d, &sb39, env);
	void *res = (*env)->CallObjectMethod(env, obj, sb39.mid, bcastrec, intfliter);
	dalvik_postcall(&d, &sb39);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb39_registerreceiver END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	return res;
}

static void* sb40_registerreceiver(JNIEnv *env, jobject obj, jobject bcastrec, 
		jobject intfliter, jobject strperm, jobject handler) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb40_registerreceiver BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_prepare(&d, &sb40, env);
	void *res = (*env)->CallObjectMethod(env, obj, sb40.mid, bcastrec, intfliter, strperm, handler);
	dalvik_postcall(&d, &sb40);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb40_registerreceiver END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	return res;
}

static void* sb41_lookuphostbyname(JNIEnv *env, jobject obj, jstring str) {
	int r = rand();
	//struct timeval t;
	////if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb41_lookuphostbyname BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
//	}
	log("libcurious: %lu%lu-%d: sb41_lookuphostbyname: about to call CallStaticObjectMethod\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	char *s = (*env)->GetStringUTFChars(env, str, 0);
	log("libcurious: %lu%lu-%d: sb41.lookupHostByName => host: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
	jobjectArray res = (*env)->CallStaticObjectMethod(env, obj, sb41.mid, str);
	log("libcurious: %lu%lu-%d: sb41_lookuphostbyname: just called CallStaticObjectMethod\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	if(str) {
		////if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb41.lookupHostByName => host: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, str)
		//}
	}
	(*env)->ReleaseStringUTFChars(env, str, s); 
	dalvik_postcall(&d, &sb41);
	////if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb41_lookuphostbyname END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return ;//res;	
}

static void* sb42_gethostname(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	////if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb42_gethostname BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
//	}
	log("libcurious: %lu%lu-%d: sb42_gethostname: about to call CallObjectMethod\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	void* res = (*env)->CallObjectMethod(env, obj, sb42.mid, NULL);
	log("libcurious: %lu%lu-%d: sb42_gethostname: just called CallObjectMethod\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	if(res) {
		char *s = (*env)->GetStringUTFChars(env, res, 0);
		////if(!hold_print) {
			gettimeofday(&t, NULL);
			log("libcurious: %lu%lu-%d: sb42.gethostname => host: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, s)
		//}
		(*env)->ReleaseStringUTFChars(env, res, s);
	}
	 
	dalvik_postcall(&d, &sb42);
	////if(!hold_print) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb42_gethostname END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	//}
	return res;	
}

static void* sb43_startactivity(JNIEnv *env, jobject obj, jobject intent) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb43_startactivity BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("libcurious: sb43_startactivity: about to set global reference on intent\n")
	seedintent = (*env)->NewGlobalRef(env, intent);
	log("libcurious: sb43_startactivity: that worked, next is checking for startup value\n")
	
	if(startup) {
		dalvik_prepare(&d, &sb43, env);
		log("libcurious: sb43_startactivity: CallVoidMethod(env, obj, sb43.mid, intent)\n")
		(*env)->CallVoidMethod(env, obj, sb43.mid, intent);
		log("libcurious: sb43_startactivity: dalvik_postcall\n")
		dalvik_postcall(&d, &sb43);
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb43_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	log("libcurious: sb43_startactivity: startup = false.  looking for jmid \"stopIntent\"\n")
	//jmethodID jmid = (*env)->GetMethodID(env, cdroid, "stopIntent", "(Landroid/content/Intent;)Z;");
	//log("libcurious: sb43_startactivity: jmid = 0x%x. Calling stopIntent\n", jmid)
	//jboolean stopintent = (*env)->CallBooleanMethod(env, cdroid_class, jmid, globalintent);
	run_curiousdroid(env, 2, r);
	uint8_t stop = (uint8_t)stopintent;
	log("libcurious: sb43_startactivity: stop = %d\n", stop)
	

	if(stop) {
		log("libcurious: sb43_startactivity: stop = %d so I'm just gonna return without doing anything.\n", stop)
		log("libcurious: %lu%lu-%d: sb43_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	else {
		log("libcurious: sb43_startactivity: stop = %d so I'll let this one fly.\n", stop)
		dalvik_prepare(&d, &sb43, env);
		(*env)->CallVoidMethod(env, obj, sb43.mid, intent);
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Problem calling the original startActivity method.\n")
		}else
			log("No problems calling the original startActivity method.\n")
		dalvik_postcall(&d, &sb43);
		log("libcurious: %lu%lu-%d: sb43_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}

}

static void* sb44_startactivity(JNIEnv *env, jobject obj, jobject intent, jobject bundle) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb44_startactivity BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("libcurious: sb44_startactivity: about to set global reference on intent\n")
	seedintent = (*env)->NewGlobalRef(env, intent);
	log("libcurious: sb44_startactivity: that worked, next is checking for startup value\n")
	
	if(startup) {
		dalvik_prepare(&d, &sb44, env);
		log("libcurious: sb44_startactivity: CallVoidMethod(env, obj, sb44.mid, intent)\n")
		(*env)->CallVoidMethod(env, obj, sb44.mid, intent, bundle);
		log("libcurious: sb44_startactivity: dalvik_postcall\n")
		dalvik_postcall(&d, &sb44);
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb44_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	log("libcurious: sb44_startactivity: startup = false.  looking for jmid \"stopIntent\"\n")
	//jmethodID jmid = (*env)->GetMethodID(env, cdroid, "stopIntent", "(Landroid/content/Intent;)Z;");
	//log("libcurious: sb44_startactivity: jmid = 0x%x. Calling stopIntent\n", jmid)
	//jboolean stopintent = (*env)->CallBooleanMethod(env, cdroid_class, jmid, globalintent);
	run_curiousdroid(env, 2, r);
	uint8_t stop = (uint8_t)stopintent;
	log("libcurious: sb44_startactivity: stop = %d\n", stop)
	

	if(stop) {
		log("libcurious: sb44_startactivity: stop = %d so I'm just gonna return without doing anything.\n", stop)
		log("libcurious: %lu%lu-%d: sb44_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	else {
		log("libcurious: sb44_startactivity: stop = %d so I'll let this one fly.\n", stop)
		dalvik_prepare(&d, &sb44, env);
		(*env)->CallVoidMethod(env, obj, sb44.mid, intent, bundle);
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Problem calling the original startActivity method.\n")
		}else
			log("No problems calling the original startActivity method.\n")
		dalvik_postcall(&d, &sb44);
		log("libcurious: %lu%lu-%d: sb44_startactivity END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}

}

static void* sb45_startactivityforresult(JNIEnv *env, jobject obj, jobject intent, jint requestcode) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb45_startactivityforresult BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("libcurious: sb45_startactivityforresult: about to set global reference on intent\n")
	seedintent = (*env)->NewGlobalRef(env, intent);
	log("libcurious: sb45_startactivityforresult: that worked, next is checking for startup value\n")
	
	if(startup) {
		dalvik_prepare(&d, &sb45, env);
		log("libcurious: sb45_startactivityforresult: CallVoidMethod(env, obj, sb45.mid, intent)\n")
		(*env)->CallVoidMethod(env, obj, sb45.mid, intent, requestcode);
		log("libcurious: sb45_startactivityforresult: dalvik_postcall\n")
		dalvik_postcall(&d, &sb45);
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb45_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	log("libcurious: sb45_startactivityforresult: startup = false.  looking for jmid \"stopIntent\"\n")
	//jmethodID jmid = (*env)->GetMethodID(env, cdroid, "stopIntent", "(Landroid/content/Intent;)Z;");
	//log("libcurious: sb45_startactivityforresult: jmid = 0x%x. Calling stopIntent\n", jmid)
	//jboolean stopintent = (*env)->CallBooleanMethod(env, cdroid_class, jmid, globalintent);
	run_curiousdroid(env, 2, r);
	uint8_t stop = (uint8_t)stopintent;
	log("libcurious: sb45_startactivityforresult: stop = %d\n", stop)
	

	if(stop) {
		log("libcurious: sb45_startactivityforresult: stop = %d so I'm just gonna return without doing anything.\n", stop)
		log("libcurious: %lu%lu-%d: sb45_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	else {
		log("libcurious: sb45_startactivityforresult: stop = %d so I'll let this one fly.\n", stop)
		dalvik_prepare(&d, &sb45, env);
		(*env)->CallVoidMethod(env, obj, sb45.mid, intent, requestcode);
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Problem calling the original startActivityForResult method.\n")
		}else
			log("No problems calling the original startActivityForResult method.\n")
		dalvik_postcall(&d, &sb45);
		log("libcurious: %lu%lu-%d: sb45_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}

}

static void* sb46_startactivityforresult(JNIEnv *env, jobject obj, jobject intent, jint requestcode, jobject bundle) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb46_startactivityforresult BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	log("libcurious: sb46_startactivityforresult: about to set global reference on intent\n")
	seedintent = (*env)->NewGlobalRef(env, intent);
	log("libcurious: sb46_startactivityforresult: that worked, next is checking for startup value\n")
	
	if(startup) {
		dalvik_prepare(&d, &sb46, env);
		log("libcurious: sb46_startactivityforresult: CallVoidMethod(env, obj, sb46.mid, intent)\n")
		(*env)->CallVoidMethod(env, obj, sb46.mid, intent, requestcode, bundle);
		log("libcurious: sb46_startactivityforresult: dalvik_postcall\n")
		dalvik_postcall(&d, &sb46);
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb46_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	log("libcurious: sb46_startactivityforresult: startup = false.  looking for jmid \"stopIntent\"\n")
	//jmethodID jmid = (*env)->GetMethodID(env, cdroid, "stopIntent", "(Landroid/content/Intent;)Z;");
	//log("libcurious: sb46_startactivityforresult: jmid = 0x%x. Calling stopIntent\n", jmid)
	//jboolean stopintent = (*env)->CallBooleanMethod(env, cdroid_class, jmid, globalintent);
	run_curiousdroid(env, 2, r);
	uint8_t stop = (uint8_t)stopintent;
	log("libcurious: sb46_startactivityforresult: stop = %d\n", stop)
	

	if(stop) {
		log("libcurious: sb46_startactivityforresult: stop = %d so I'm just gonna return without doing anything.\n", stop)
		log("libcurious: %lu%lu-%d: sb46_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	else {
		log("libcurious: sb46_startactivityforresult: stop = %d so I'll let this one fly.\n", stop)
		dalvik_prepare(&d, &sb46, env);
		(*env)->CallVoidMethod(env, obj, sb46.mid, intent, requestcode, bundle);
		jthrowable exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Problem calling the original startActivityForResult method.\n")
		}else
			log("No problems calling the original startActivityForResult method.\n")
		dalvik_postcall(&d, &sb46);
		log("libcurious: %lu%lu-%d: sb46_startactivityforresult END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}

}

int layercake = 0;
static void* sb47_finish(JNIEnv *env, jobject obj) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb47_finish BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	jclass act = (*env)->FindClass(env, "android/app/Activity");
	//log("Just called FindClass in sb47.\n")
	jthrowable exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling FindClass-Activity in sb47.\n")
	}
	jmethodID getlocalclassname = (*env)->GetMethodID(env, act, "getLocalClassName", "()Ljava/lang/String;");
	exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling GetMethodID-getLocalClassName in sb47.\n")
	}
	jstring classname = (*env)->CallObjectMethod(env, obj, getlocalclassname);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling CallObjectMethod-getLocalClassName in sb47.\n")
	}
	char *s = (*env)->GetStringUTFChars(env, classname, 0);
	log("Activity name = %s\n", s)
	(*env)->ReleaseStringUTFChars(env, classname, s); 
	jmethodID jmid =  (*env)->GetMethodID(env, act, "isTaskRoot", "()Z");
	//log("Just called GetMethodID in sb47.\n")
	exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling GetMethodID-isTaskRoot in sb47.\n")
	}
	jboolean isroot2 = (*env)->CallBooleanMethod(env, obj, jmid);
	log("Just called CallBooleanMethod in sb47.\n")
	exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem calling CallBooleanMethod in sb47.\n")
	}
	curract = (*env)->NewGlobalRef(env, obj);
	uint8_t root;// = (uint8_t)isroot;
	if(!startup) {
		run_curiousdroid(env, 3, r);
		uint8_t root2 = (uint8_t)isroot2;
		log("About to test isroot as uint8_t.\n")
		root = (uint8_t)isroot;
	}
	else 
		root = 0;

	if(root) {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb47_finish -> blocking finish call.\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb47_finish END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		return;
	}
	else {
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb47_finish: Not root task.  Allowing finish() call to run.\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
		dalvik_prepare(&d, &sb47, env);
		(*env)->CallVoidMethod(env, obj, sb47.mid);
		dalvik_postcall(&d, &sb47);
		gettimeofday(&t, NULL);
		log("libcurious: %lu%lu-%d: sb47_finish END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	}
}

static void* sb49_transact(JNIEnv *env, jobject obj, int code, jobject parcel_in, jobject parcel_out, int flags) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb49_transact BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb49, env);
	jboolean res = (*env)->CallBooleanMethod(env, obj, sb49.mid, code, parcel_in, parcel_out, flags);
	dalvik_postcall(&d, &sb49);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb49_transact END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	return res;
}

static void* sb50_ontransact(JNIEnv *env, jobject obj, int code, jobject parcel_in, jobject parcel_out, int flags) {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb50_ontransact BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb50, env);
	jboolean res = (*env)->CallBooleanMethod(env, obj, sb50.mid, code, parcel_in, parcel_out, flags);
	dalvik_postcall(&d, &sb50);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb50_ontransact END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	return res;
}

static void* sb51_startservice(JNIEnv *env, jobject obj, jobject intent) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb51_startservice BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb51, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb51.mid, intent);
	dalvik_postcall(&d, &sb51);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb51_startservice END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	return res;
}

static void* sb52_parse(JNIEnv *env, jobject obj, jobject str) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb52_parse BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	printString(env, str, "sb52_parse->str: ", r);
	dalvik_prepare(&d, &sb52, env);
	jobject res = (*env)->CallObjectMethod(env, obj, sb52.mid, str);
	printString(env, res, "sb52_parse->res: ", r);
	dalvik_postcall(&d, &sb52);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb52_parse END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	return res;
}

static void* sb53_loadurl(JNIEnv *env, jobject obj, jobject url) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb53_loadurl BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb53, env);
	(*env)->CallVoidMethod(env, obj, sb53.mid, url);
	dalvik_postcall(&d, &sb53);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb53_loadurl END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb54_loadurl(JNIEnv *env, jobject obj, jobject url, jobject map) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb54_loadurl BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb54, env);
	(*env)->CallVoidMethod(env, obj, sb54.mid, url, map);
	dalvik_postcall(&d, &sb54);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb54_loadurl END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb55_loaddatabaseurl(JNIEnv *env, jobject obj, jobject url, jobject data, jobject mimetype, jobject encoding, jobject histurl) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb55, env);
	(*env)->CallVoidMethod(env, obj, sb55.mid, url, data, mimetype, encoding, histurl);
	//char *s = (*env)->GetStringUTFChars(env, url, 0);
	printString(env, url, "sb55_loaddatabaseurl->url:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->url: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, url)
	printString(env, data, "sb55_loaddatabaseurl->data:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->data: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, data)
	printString(env, mimetype, "sb55_loaddatabaseurl->mimetype:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->mimetype: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, mimetype)
	printString(env, encoding, "sb55_loaddatabaseurl->encoding:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->encoding: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, encoding)
	printString(env, histurl, "sb55_loaddatabaseurl->histurl:", r);
	//log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl->histurl: %s\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r, histurl)
	dalvik_postcall(&d, &sb55);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb55_loaddatabaseurl END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb56_loaddata(JNIEnv *env, jobject obj, jobject str1, jobject str2, jobject str3) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb56_loaddata BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb56, env);
	(*env)->CallVoidMethod(env, obj, sb56.mid, str1, str2, str3);
	dalvik_postcall(&d, &sb56);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb56_loaddata END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

static void* sb57_addjavascript(JNIEnv *env, jobject obj, jobject obj1, jobject str) {
	int r = rand();
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb57_addjavascript BEGIN\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
	dalvik_prepare(&d, &sb57, env);
	(*env)->CallVoidMethod(env, obj, sb57.mid, obj1, str);
	dalvik_postcall(&d, &sb57);
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: sb57_addjavascript END\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)
}

/*void do_patch_onresume()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb0,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onResume",//onResume", // method name
		"()V", // method signature: (ARGUMENTS in L format)Return_value
		1, // paramter size = number of args + 1 (if method not static)
		sb0_onresume); // function to use for patch
	dalvik_hook(&d, &sb0);
	
}*/

void do_patch_onresume()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb0,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onPostResume",//onResume", // method name
		"()V", // method signature: (ARGUMENTS in L format)Return_value
		1, // paramter size = number of args + 1 (if method not static)
		sb0_onresume); // function to use for patch
	dalvik_hook(&d, &sb0);
	
}

void do_patch_alertdialog()
{
	dalvik_hook_setup(
		&sb2,
		"Landroid/app/Dialog;",
		//"onResume",
		//"()V",
		"onWindowFocusChanged",
		"(Z)V",
		2,
		ondialog);
	dalvik_hook(&d, &sb2);
}

void do_patch_onfocuschange()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onWindowFocusChanged", // method name
		"(Z)V", // method signature: (ARGUMENTS in L format)Return_value
		2, // paramter size = number of args + 1 (if method not static)
		onwindowfocuschanged); // function to use for dalvik_hook
	dalvik_hook(&d, &sb1);
}

void do_patch_fragment()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb3,  // hook structure
		"Landroid/support/v4/app/FragmentActivity;",//Landroid/support/v4/app/Fragment;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onResume", // method name
		"()V", // method signature: (ARGUMENTS in L format)Return_value
		2, // paramter size = number of args + 1 (if method not static)
		onFragment); // function to use for patch
	dalvik_hook(&d, &sb3);
	
}

void do_patch_actfrag() {
	dalvik_hook_setup(
		&sb3,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onAttachFragment", // method name
		"(Landroid/app/Fragment;)V", // method signature: (ARGUMENTS in L format)Return_value
		2, // paramter size = number of args + 1 (if method not static)
		onFragmentTransaction); // function to use for dalvik_hook
	dalvik_hook(&d, &sb3);
}

void do_patch_location() {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: do_patch_loction\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	// Location class methods hooked here
	dalvik_hook_setup(&sb24, "Landroid/location/Location;", "toString", "()Ljava/lang/String;", 1, sb24_tostring);
	dalvik_hook(&d, &sb24);

	dalvik_hook_setup(&sb25, "Landroid/location/Location;", "isFromMockProvider", "()Z", 1, sb25_isfrommockprovider);
	dalvik_hook(&d, &sb25);

	dalvik_hook_setup(&sb26, "Landroid/location/Location;", "convert", "(Ljava/lang/String;)D", 2, sb26_convert);
	dalvik_hook(&d, &sb26);

	// Address class methods hooked here
	dalvik_hook_setup(&sb27, "Landroid/location/Address;", "toString", "()Ljava/lang/String;", 1, sb27_toString);
	dalvik_hook(&d, &sb27);

	dalvik_hook_setup(&sb28, "Landroid/location/Address;", "getPhone", "()Ljava/lang/String;", 1, sb28_getphone);
	dalvik_hook(&d, &sb28);

	
}

void do_patch_messaging() {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: do_patch_messaging\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_hook_setup(&sb29, "Landroid/telephony/SmsManager;", "sendTextMessage", "(Ljava/lang/String;)V", 2, sb29_sendtextmessage);
	dalvik_hook(&d, &sb29);

	dalvik_hook_setup(&sb30, "Landroid/telephony/SmsManager;", "sendDataMessage",
		"(Ljava/lang/String;Ljava/lang/String;[BLandoid/app/PendingIntent;Landroid/app/PendingIntent;)V", 6, sb30_senddatamessage);
	dalvik_hook(&d, &sb30);

	dalvik_hook_setup(&sb31, "Landroid/telephony/SmsMessage;", "getMessageBody", "()Ljava/lang/String;", 1, sb31_getmessagebody);
	dalvik_hook(&d, &sb31);

	dalvik_hook_setup(&sb32, "Landroid/telephony/SmsMessage;", "getOriginatingAddress", "()Ljava/lang/String;", 1, sb32_getorigiatingaddress);
	dalvik_hook(&d, &sb32);

	dalvik_hook_setup(&sb33, "Landroid/telephony/SmsMessage;", "getServiceCenterAddress", "()Ljava/lang/String;", 1, sb33_getservicecenteraddress);
	dalvik_hook(&d, &sb33);
}

void do_patch_networking() {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: do_patch_networking\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_hook_setup(&sb34, "Landroid/net/http/AndroidHttpClient;", "execute",
		"(Lorg/apache/http/HttpHost;Lorg/apache/http/HttpRequest;)Lorg/apache/http/HttpResponse;", 3, sb34_execute);
	dalvik_hook(&d, &sb34);

	dalvik_hook_setup(&sb35, "Landroid/net/Uri;", "fromParts", 
		"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;", 4, sb35_fromparts);
	dalvik_hook(&d, &sb35);

	dalvik_hook_setup(&sb36, "Landroid/net/Uri;", "withAppendedPath", 
		"(Landroid/net/Uri;Ljava/lang/String;)Landroid/net/Uri;", 3, sb36_withappendedpaths);
	dalvik_hook(&d, &sb36);

	dalvik_hook_setup(&sb37, "Landroid/net/Uri;", "toString", "()Ljava/lang/String;", 1, sb37_tostring);
	dalvik_hook(&d, &sb37);

	//dalvik_hook_setup(&sb52, "Landroid/net/Uri;", "parse", "(Ljava/lang/String;)Landroid/net/Uri;", 2, sb52_parse);
	//dalvik_hook(&d, &sb52);

//	dalvik_hook_setup(&sb41, "Ljava/net/InetAddress;", "lookupHostByName", 
//		"(Ljava/lang/String;)[Ljava/net/InetAddress;", 2, sb41_lookuphostbyname);
//	dalvik_hook(&d, &sb41);

	dalvik_hook_setup(&sb42, "Ljava/net/InetAddress;", "getHostName", "()Ljava/lang/String;", 1, sb42_gethostname);
	dalvik_hook(&d, &sb42);

	dalvik_hook_setup(&sb53, "Landroid/webkit/WebView;", "loadUrl", "(Ljava/lang/String;)V", 2, sb53_loadurl);
	dalvik_hook(&d, &sb53);

	dalvik_hook_setup(&sb54, "Landroid/webkit/WebView;", "loadUrl", "(Ljava/lang/String;Ljava/util/Map;)V", 3, sb54_loadurl);
	dalvik_hook(&d, &sb54);

	dalvik_hook_setup(&sb55, "Landroid/webkit/WebView;", "loadDataWithBaseURL", 
		"(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V", 6, sb55_loaddatabaseurl);
	dalvik_hook(&d, &sb55);

	dalvik_hook_setup(&sb56, "Landroid/webkit/WebView;", "loadData", "(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V",
		4, sb56_loaddata);
	dalvik_hook(&d, &sb56);

	dalvik_hook_setup(&sb57, "Landroid/webkit/WebView;", "addJavascriptInterface", "(Ljava/lang/Object;Ljava/lang/String;)V",
		3, sb57_addjavascript);
	dalvik_hook(&d, &sb57);
}

void do_patch_intentbroadcast() {
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: do_patch_intentbroadcast\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_hook_setup(&sb38, "Landroid/content/BroadcastReceiver;", "onReceive",
		"(Landroid/content/Context;Landroid/content/Intent;)V", 3, sb38_onReceive);
	dalvik_hook(&d, &sb38);

	dalvik_hook_setup(&sb39, "Landroid/content/Context;", "registerReceiver", 
		"(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;", 3, sb39_registerreceiver);
	dalvik_hook(&d, &sb39);

	dalvik_hook_setup(&sb40, "Landroid/content/Context;", "registerReceiver",
	 "(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;", 
	 5, sb40_registerreceiver);
	dalvik_hook(&d, &sb40);

	dalvik_hook_setup(&sb43, "Landroid/app/Activity;", "startActivity", "(Landroid/content/Intent;)V", 2, sb43_startactivity);
	dalvik_hook(&d, &sb43);

	dalvik_hook_setup(&sb44, "Landroid/app/Activity;", "startActivity", "(Landroid/content/Intent;Landroid/os/Bundle;)V", 
		3, sb44_startactivity);
	dalvik_hook(&d, &sb44);

	dalvik_hook_setup(&sb45, "Landroid/app/Activity;", "startActivityForResult", 
		"(Landroid/content/Intent;I)V", 3, sb45_startactivityforresult);
	dalvik_hook(&d, &sb45);	

	dalvik_hook_setup(&sb46, "Landroid/app/Activity;", "startActivityForResult", 
		"(Landroid/content/Intent;ILandroid/os/Bundle;)V", 4, sb46_startactivityforresult);
	dalvik_hook(&d, &sb46);	

	dalvik_hook_setup(&sb47, "Landroid/app/Activity;", "finish", "()V", 1, sb47_finish);
	dalvik_hook(&d, &sb47);

	//dalvik_hook_setup(&sb48, "Landroid/app/Activity", "startActivityFromFragment", "(Landroid/app/Fragment;Landroid/content/Intent;I",
	//	4, sb48_startactivityfromfragment);
	//dalvik_hook(&d, &sb48);

	dalvik_hook_setup(&sb49, "Landroid/os/Binder;", "transact", "(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z", 5, sb49_transact);
	dalvik_hook(&d, &sb49);

	dalvik_hook_setup(&sb50, "Landroid/os/Binder;", "onTransact", "(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z", 5, sb50_ontransact);
	dalvik_hook(&d, &sb50);

	dalvik_hook_setup(&sb51, "Landroid/content/Context;", "startService", "(Landroid/content/Intent;)Landroid/content/ComponentName;",
		2, sb51_startservice);
	dalvik_hook(&d, &sb51);
}

void do_patch_mon()
{
	int r = rand();
	//struct timeval t;
	gettimeofday(&t, NULL);
	log("libcurious: %lu%lu-%d: do_patch_mon\n", (unsigned long)t.tv_sec, (unsigned long)t.tv_usec, r)

	dalvik_hook_setup(&sb4, "Ljava/lang/StringBuffer;",  "toString",  "()Ljava/lang/String;", 1, sb4_tostring);
	dalvik_hook(&d, &sb4);

	//dalvik_hook_setup(&sb5, "Ljava/lang/StringBuilder;",  "toString",  "()Ljava/lang/String;", 1, sb5_tostring);
	//dalvik_hook(&d, &sb5);

	dalvik_hook_setup(&sb6, "Ljava/lang/String;", "compareTo", "(Ljava/lang/String;)I", 2, sb6_compareto);
	dalvik_hook(&d, &sb6);

	dalvik_hook_setup(&sb7, "Ljava/nio/ByteBuffer;", "compareTo", "(Ljava/nio/ByteBuffer;)I", 2, sb7_compareto);
	dalvik_hook(&d, &sb7);

	dalvik_hook_setup(&sb8, "Ljava/nio/ByteBuffer;", "get", "(I)B", 2, sb8_get);
	dalvik_hook(&d, &sb8);

	dalvik_hook_setup(&sb9, "Ljava/nio/ByteBuffer;", "get", "()B", 2, sb9_get);
	dalvik_hook(&d, &sb9);

	dalvik_hook_setup(&sb10, "Ljava/nio/ByteBuffer;", "getInt", "(I)I", 2, sb10_getint);
	dalvik_hook(&d, &sb10);

	dalvik_hook_setup(&sb11, "Ljava/lang/String;", "compareToIgnoreCase", "(Ljava/lang/String;)I", 2, sb11_comparetocase);
	dalvik_hook(&d, &sb11);

	//dalvik_hook_setup(&sb12, "Ljava/lang/String;", "equalsIgnoreCase", "(Ljava/lang/String;)Z", 2, sb12_equalsIgnoreCase);
	//dalvik_hook(&d, &sb12);
	
	//dalvik_hook_setup(&sb16, "Ljava/lang/String;", "equals", "(Ljava/lang/Object;)Z", 2, sb16_equals);
	//dalvik_hook(&d, &sb16);

//	dalvik_hook_setup(&sb13, "Ljava/lang/String;", "contains", "(Ljava/lang/CharSequence;)Z", 2, sb13_contains);
//	dalvik_hook(&d, &sb13);

	dalvik_hook_setup(&sb14, "Ljava/lang/String;", "contentEquals", "(Ljava/lang/StringBuffer;)Z", 2, sb14_contentEquals);
	dalvik_hook(&d, &sb14);

	dalvik_hook_setup(&sb15, "Ljava/lang/String;", "indexOf", "(Ljava/lang/String;I)I", 3, sb15_indexof);
	dalvik_hook(&d, &sb15);
	
	//dalvik_hook_setup(&sb16, "Ljava/lang/StringBuffer;", "indexOf", "(Ljava/lang/String;I)I", 3, sb16_indexof);
	//dalvik_hook(&d, &sb16);
	
	//dalvik_hook_setup(&sb17, "Ljava/lang/String;", "endsWith", "(Ljava/lang/String;)Z", 2, sb17_endswith);
	//dalvik_hook(&d, &sb17);
	
	//dalvik_hook_setup(&sb18, "Ljava/lang/String;", "startsWith", "(Ljava/lang/String;I)Z", 3, sb18_startswith);
	//dalvik_hook(&d, &sb18);
	
	dalvik_hook_setup(&sb19, "Ljava/lang/String;", "matches", "(Ljava/lang/String;)Z", 2, sb19_matches);
	dalvik_hook(&d, &sb19);
/*	
	dalvik_hook_setup(&sb4, "Ljava/lang/StringBuffer;", "append", "(Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;", 2, sb4_append);
	dalvik_hook(&d, &sb4);
*/
/*	
	dalvik_hook_setup(&sb17, "Ljava/lang/StringBuilder;", "append", "(Ljava/lang/StringBuffer;)Ljava/lang/StringBuilder;", 2, sb17_append);
	dalvik_hook(&d, &sb17);

	dalvik_hook_setup(&sb18, "Ljava/lang/StringBuilder;", "append", "(Ljava/lang/String;)Ljava/lang/StringBuilder;", 2, sb18_append);
	dalvik_hook(&d, &sb18);
*/	
//	dalvik_hook_setup(&sb19, "Ljava/lang/StringBuilder;", "indexOf", "(Ljava/lang/String;I)I", 3, sb19_indexof);
//	dalvik_hook(&d, &sb19);

/*	
	dalvik_hook_setup(&sb22, "Ljava/lang/StringBuffer;", "<init>", "(Ljava/lang/String;)V", 2, sb22_init);
	dalvik_hook(&d, &sb22);
*/	
//	dalvik_hook_setup(&sb21, "Ljava/lang/String;", "getBytes", "()[B", 3, sb21_getbytes);
//	dalvik_hook(&d, &sb21);

/*	
	dalvik_hook_setup(&sb12, "Ljava/lang/StringBuffer;", "append", "(Ljava/lang/String;)Ljava/lang/StringBuffer;", 2, sb12_append);
	dalvik_hook(&d, &sb12);

	dalvik_hook_setup(&sb15, "Ljava/lang/StringBuffer;", "append", "(Ljava/lang/CharSequence;)Ljava/lang/StringBuffer;", 2, sb15_append);
	dalvik_hook(&d, &sb15);
*/
	dalvik_hook_setup(&sb20, "Ljava/lang/Class;", "getMethod", "(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;", 3, sb20_getmethod);
	dalvik_hook(&d, &sb20);

//	dalvik_hook_setup(&sb21, "Ljava/lang/Class;", "getMethods", "()[Ljava/lang/reflect/Method;", 1, sb21_getmethods);
//	dalvik_hook(&d, &sb21);

//	dalvik_hook_setup(&sb22, "Ljava/lang/Class;", "getName", "()Ljava/lang/String;", 1, sb22_getname);
//	dalvik_hook(&d, &sb22);

//	dalvik_hook_setup(&sb23, "Ljava/lang/Class;", "getSimpleName", "()Ljava/lang/String;", 1, sb23_getsimplename);
//	dalvik_hook(&d, &sb23);
}

/*void do_patch_fragmentTransaction() {
	dalvik_hook_setup(
		&sb3,
		"Landroid/app/FragmentTransaction;",
		//"show",
		"replace",
		//"(Landroid/app/Fragment;)Landroid/app/FragmentTransaction;",
		"("
		2,
		onFragmentTransaction);
	dalvik_hook(&d, &sb3);
}

/*void do_patch_oncontentchange() {
	dalvik_hook_setup(
		&sb1, 
		"Landroid/app/Activity;",
		"onConfigurationChange",
		"(Landroid/content/res/Configuration;)V",
		//"onContentChanged",
		//"()V",
		2,
		sb1_onresume);
	dalvik_hook(&d, &sb1);
}

void do_patch_onpause()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onPause", // method name
		"()V", // method signature: (ARGUMENTS in L format)Return_value
		1, // paramter size = number of args + 1 (if method not static)
		sb1_onpause); // function to use for patch
	dalvik_hook(&d, &sb1);
}*/

/*void do_patch_fragmentActivity()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Landroid/support/v4/app/FragmentActivity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"startActivityFromFragment",//"onResume", // method name
		"(Landroid/support/v4/app/Fragment;Landroid/content/Intent;)V", // method signature: (ARGUMENTS in L format)Return_value
		3, // paramter size = number of args + 1 (if method not static)
		sb1_onresume); // function to use for patch
	dalvik_hook(&d, &sb1);
	
}*/

int sock, len;
struct sockaddr_un remote;
jobject curiousdroid;
void* run_curiousdroid(JNIEnv *env, jobject obj, int type, int r)
{
	hold_print = 1;
	/*int i = dexstuff_loaddex(&d, "/data/local/tmp/classes.dex");

	void *clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.CuriousDroid", i);
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)
	clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.PressGenerator", i);
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)
	clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.ExecutionState", i); 
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)
	clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.ActivityContainer", i);
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)
	clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.DetermineContext", i);
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)
	clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.TextFieldComparator", i);
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)
	clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.ViewPositionComparator", i);
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)
	clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.ViewNode", i);
	log("clazz1 = 0x%x, cookie = 0x%x\n", clazz1, i)

	jclass cdroid = (*env)->FindClass(env, "edu/neu/ccs/curiousdroid/CuriousDroid");
	jthrowable exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Couldn't find CuriousDroid class.\n")
	}
	log("cdroid = 0x%x\n", cdroid)

	jmethodID cdroid_init = (*env)->GetMethodID(env, cdroid, "<init>", "(Landroid/view/View;)V");
	exc = (*env)->ExceptionOccurred(env);
	if(exc) {
		(*env)->ExceptionDescribe(env);
		log("Problem defining CuriousDroid constructor.\n")
	}
	log("cdroid_init = 0x%x\n", cdroid_init)*/
	jthrowable exc;// = (*env)->ExceptionOccurred(env);
	if(viewcalled == 0) {
		//cdroid_class = (*env)->NewObject(env, cdroid, cdroid_init, seedview, NULL);
		//cdroid_class = (*env)->NewGlobalRef(env, cdroid_class);
		curiousdroid = loadclass_a23(env, obj, "/data/local/tmp/classes.zip","edu.neu.ccs.curiousdroid.CuriousDroid","android/app/Activity");

	value args[2];
	args[0].l = curiousdroid;
	args[1].l = (*env)->NewObjectArray(env, 1, (*env)->FindClass(env,"java/lang/Object"), 0);
	(*env)->SetObjectArrayElement(env, args[1].l, 0,seedview);
	
	jobjectArray sig = (*env)->NewObjectArray(env, 1,(*env)->FindClass(env, "java/lang/Class"), 0);
	(*env)->SetObjectArrayElement(env, sig, 0, (*env)->FindClass(env,"android/view/View"));
	
	jobject result = reflect_call(env, curiousdroid, "fakeConstructor", sig, args);

		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Couldn't generate CuriousDroid object.\n")


		if((sock = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
			log("Couldn't create a socket\n")
		}

		remote.sun_family = AF_UNIX;
		strcpy(remote.sun_path, "/data/local/tmp/eventsocket");
		len = strlen(remote.sun_path) + sizeof(remote.sun_family);
		if(connect(sock, (struct sockaddr *)&remote, len) == -1) {
			log("Unable to connect socket to listener\n")
		}
	}

	const char* jstring_c;
	jstring mystring;
	if(type == 0) {
	    jmethodID jmid = (*env)->GetMethodID(env, cdroid, "expandChildViews", "(Landroid/view/View;I)Ljava/lang/String;");
	   // log("jmid getID = 0x%x\n", jmid)
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandChildViews method ID.\n")
		}
		mystring = (*env)->CallObjectMethod(env, cdroid_class, jmid, seedview, 0);
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem calling expanChildViews: mystring = %s\n", jstring_c)// mystring)
		
		viewcalled++;
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call expandChildViews from native side.\n")
			log("Failed calling expandChildViews.\n")
		}
		hold_print = 0;
	}
	else if(type == 1) {
		jmethodID jmid = (*env)->GetMethodID(env, cdroid, "expandDialogViews", "(Landroid/view/View;)Ljava/lang/String;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandDialogViews method ID.\n")
		}
		mystring = (*env)->CallObjectMethod(env, cdroid_class, jmid, seedview);
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		viewcalled++;
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call handleDialog from native side.\n")
			log("Failed calling handleDialog.\n")
		}
		hold_print = 0;
	}
	else if(type == 2) {
		jmethodID jmid = (*env)->GetMethodID(env, cdroid, "stopIntent", "(Landroid/content/Intent;)Z");
		log("libcurious: run_curiousdroid: jmid = 0x%x. Calling stopIntent\n", jmid)
		stopintent = (*env)->CallBooleanMethod(env, cdroid_class, jmid, seedintent);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
			log("Failed trying to call stopIntent from native side.\n")
			log("Failed calling stopIntent.\n")
		}
		uint8_t stop = (uint8_t)stopintent;
		log("libcurious: run_curiousdroid: stop = %d\n", stop)
		hold_print = 0;
		return;
	}
	else if(type == 3) {
		log("About to define isRoot method\n")
		jmethodID jmid = (*env)->GetMethodID(env, cdroid, "checkRoot", "(Landroid/app/Activity;)Z");
		log("checkRoot mid = 0x%x\n", jmid)
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get isRoot method ID.\n")
		}
		log("About to call isRoot method\n")
		isroot = (*env)->CallBooleanMethod(env, cdroid_class, jmid, curract);
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed calling isRoot.\n")
		}
		log("About to set root to value of isroot\n")
		uint8_t root = (uint8_t)isroot;
		if(root)
			log("root = true -> %d\n", root)
		else
			log("root = flase -> %d\n", root)
		hold_print = 0;
		return;
	}
	else {
		log("Called from onResume.\n")
		jmethodID jmid = (*env)->GetMethodID(env, cdroid, "expandChildViews", "(Landroid/view/View;I)Ljava/lang/String;");
		exc = (*env)->ExceptionOccurred(env);
		if(exc) {
			(*env)->ExceptionDescribe(env);
		 	log("Failed to get expandChildViews method ID.\n")
		}
		mystring = (*env)->CallObjectMethod(env, cdroid_class, jmid, seedview, 1);
		jstring_c = (*env)->GetStringUTFChars(env, mystring, 0);
		exc = (*env)->ExceptionOccurred(env);
		if(exc)
			log("Problem calling expanChildViews: mystring = %s\n", jstring_c)// mystring)
		
		(*env)->ReleaseStringUTFChars(env, mystring, jstring_c); 
		viewcalled++;
		hold_print = 0;
		return;
	}

	hold_print = 0;
	
	/*isrootactivity = "root";
	if(send(sock, isrootactivity, strlen(isrootactivity), 0) == -1) {
		log("Unable to send root event.\n")
	}*/
	if(send(sock, jstring_c, strlen(jstring_c), 0) == -1) {
		log("Unable to send event.\n")
	}
	else {
		log("Send complete.\n")
	}
	(*env)->ReleaseStringUTFChars(env, mystring, jstring_c); 

}




// END --- load class

// ---- don't need to modify ----

static int my_epoll_wait(int epfd, struct epoll_event *events, int maxevents, int timeout)
{
	int (*orig_epoll_wait)(int epfd, struct epoll_event *events, int maxevents, int timeout);
	srand(1013);
    orig_epoll_wait = (void*)eph.orig;

    hook_precall(&eph);

    dexstuff_resolv_dvm(&d);
    //
	do_patch_onresume();
	do_patch_alertdialog();
	do_patch_onfocuschange();
	//do_patch_fragment();
	//do_patch_actfrag();
	do_patch_messaging();
	do_patch_location();
	do_patch_networking();
	do_patch_intentbroadcast();
	do_patch_mon();
	//do_patch_fragmentTransaction();
    int res = orig_epoll_wait(epfd, events, maxevents, timeout);
    //dvmDumpAllClasses_fnPtr(&d);
    //d.dvmDumpAllClasses_fnPtr(0);
   return res;
}

void my_init(void)
{
	log("%s started\n", __FILE__)
 
 	// for libbase
	set_logfunction(my_log);
	// for libdalvikhook
	dalvikhook_set_logfunction(my_log);

    hook(&eph, getpid(), "libc.", "epoll_wait", my_epoll_wait, 0);
}