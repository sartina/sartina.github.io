void* set_logfunction(void *func);
