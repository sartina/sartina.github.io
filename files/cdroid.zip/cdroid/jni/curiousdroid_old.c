#define _GNU_SOURCE
#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/select.h>
#include <string.h>
#include <termios.h>
#include <pthread.h>
#include <sys/epoll.h>

#include <jni.h>
#include <stdlib.h>

#include <stdint.h>
#include <fcntl.h>
#include <sys/ioctl.h>
#include <errno.h>

#include "hook.h"
#include "dexstuff.h"
#include "dalvik_hook.h"
#include "base.h"
#include "log.h"

// from <linux/input.h>

struct input_event {
	struct timeval time;
	__u16 type;
	__u16 code;
	__s32 value;
};

#define EVIOCGVERSION		_IOR('E', 0x01, int)			/* get driver version */
#define EVIOCGID		_IOR('E', 0x02, struct input_id)	/* get device ID */
#define EVIOCGKEYCODE		_IOR('E', 0x04, int[2])			/* get keycode */
#define EVIOCSKEYCODE		_IOW('E', 0x04, int[2])			/* set keycode */

#define EVIOCGNAME(len)		_IOC(_IOC_READ, 'E', 0x06, len)		/* get device name */
#define EVIOCGPHYS(len)		_IOC(_IOC_READ, 'E', 0x07, len)		/* get physical location */
#define EVIOCGUNIQ(len)		_IOC(_IOC_READ, 'E', 0x08, len)		/* get unique identifier */

#define EVIOCGKEY(len)		_IOC(_IOC_READ, 'E', 0x18, len)		/* get global keystate */
#define EVIOCGLED(len)		_IOC(_IOC_READ, 'E', 0x19, len)		/* get all LEDs */
#define EVIOCGSND(len)		_IOC(_IOC_READ, 'E', 0x1a, len)		/* get all sounds status */
#define EVIOCGSW(len)		_IOC(_IOC_READ, 'E', 0x1b, len)		/* get all switch states */

#define EVIOCGBIT(ev,len)	_IOC(_IOC_READ, 'E', 0x20 + ev, len)	/* get event bits */
#define EVIOCGABS(abs)		_IOR('E', 0x40 + abs, struct input_absinfo)		/* get abs value/limits */
#define EVIOCSABS(abs)		_IOW('E', 0xc0 + abs, struct input_absinfo)		/* set abs value/limits */

#define EVIOCSFF		_IOC(_IOC_WRITE, 'E', 0x80, sizeof(struct ff_effect))	/* send a force effect to a force feedback device */
#define EVIOCRMFF		_IOW('E', 0x81, int)			/* Erase a force effect */
#define EVIOCGEFFECTS		_IOR('E', 0x84, int)			/* Report number of effects playable at the same time */

#define EVIOCGRAB		_IOW('E', 0x90, int)			/* Grab/Release device */

// end <linux/input.h>

#undef log

#define log(...) \
        {FILE *fp = fopen("/data/local/tmp/log", "a+");\
        fprintf(fp, __VA_ARGS__);\
        fclose(fp);}

void __attribute__ ((constructor)) my_init(void);

static struct hook_t eph;
static struct dexstuff_t d;

static void my_log(char *msg)
{
	log(msg)
}

// START --- change stuff ---
static struct dalvik_hook_t sb1;

void* loadclass(JNIEnv *env);
void* loadclass_alt(JNIEnv *env);
void call_stuff(JNIEnv *env);

int viewcalled = 0;
jobject seedview;
// global for the loaded class
void *cdroid;
jobject viewlist;
void* viewnodecls;
void* cdroid_class;

int sendevent(int argc, char *argv[])
{
    int i;
    int fd;
    int ret;
    int version;
    struct input_event event;

    if(argc != 5) {
        fprintf(stderr, "use: %s device type code value\n", argv[0]);
        return 1;
    }

    fd = open(argv[1], O_RDWR);
    if(fd < 0) {
        fprintf(stderr, "could not open %s, %s\n", argv[optind], strerror(errno));
        return 1;
    }
    if (ioctl(fd, EVIOCGVERSION, &version)) {
        fprintf(stderr, "could not get driver version for %s, %s\n", argv[optind], strerror(errno));
        return 1;
    }
    memset(&event, 0, sizeof(event));
    event.type = atoi(argv[2]);
    event.code = atoi(argv[3]);
    event.value = atoi(argv[4]);
    ret = write(fd, &event, sizeof(event));
    if(ret < sizeof(event)) {
        fprintf(stderr, "write event failed, %s\n", strerror(errno));
        return -1;
    }
    return 0;
}

static void* sb1_onresume(JNIEnv *env,  jobject obj) {
	log("onresume\n")
	log("env = 0x%x\n", env)
	log("obj = 0x%x\n", obj)
	
	
	//jclass act = (*env)->GetObjectClass(env, obj);
	jclass act = (*env)->FindClass(env, "android/app/Activity");
	
	jboolean isact = (*env)->IsInstanceOf(env, obj, act);
	if(isact)
		log("isact = %d, obj is Activity\n", isact)
	else
		log("isact = %d, obj is not an Activity\n", isact)
	
	
			
	jmethodID jmid_win  = (*env)->GetMethodID(env, act, "getWindow", "()Landroid/view/Window;");
	log("jmid_win = 0x%x\n", jmid_win)
	jobject window      = (*env)->CallObjectMethod(env, obj, jmid_win);
	log("window = 0x%x\n", window)
	jclass win       = (*env)->FindClass(env, "android/view/Window");
	jmethodID jmid_view = (*env)->GetMethodID(env, win, "getDecorView", "()Landroid/view/View;");
	log("jmid_view = 0x%x\n", jmid_view)
	jobject   view      = (*env)->CallObjectMethod(env, window, jmid_view);
	log("view = 0x%x\n", view)
	seedview = (*env)->NewGlobalRef(env, view);
	
	//seedview = view;
	//loadclass_alt(env);
	//call_stuff(env);	
	
	dalvik_prepare(&d, &sb1, env);
	(*env)->CallVoidMethod(env, obj, sb1.mid, NULL); 
	log("success calling : %s\n", sb1.method_name)
	loadclass_alt(env);
	dalvik_postcall(&d, &sb1);
	//sleep(10);
}

static void* sb1_onpause(JNIEnv *env, jobject obj)
{
	log("onPause\n")
	jclass cdroid = (*env)->FindClass(env, "edu/neu/ccs/curiousdroid/CuriousDroid");
	jmethodID jmid = (*env)->GetMethodID(env, cdroid, "setPaused", "(I)V");
	log("setPaused method defined. Calling...\n")
	(*env)->CallVoidMethod(env, cdroid_class, jmid, 1, NULL);
	log("onPause method called successfully.\n")

	dalvik_prepare(&d, &sb1, env);
	(*env)->CallVoidMethod(env, obj, sb1.mid, NULL); 
	log("success calling : %s\n", sb1.method_name)
	dalvik_postcall(&d, &sb1);

}

void do_patch_onresume()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onWindowFocusChanged", // method name
		"(Z)V", // method signature: (ARGUMENTS in L format)Return_value
		2, // paramter size = number of args + 1 (if method not static)
		sb1_onresume); // function to use for patch
	dalvik_hook(&d, &sb1);
	
}

void do_patch_onpause()
{
	//d.dvmDumpAllClasses_fnPtr(0);
	dalvik_hook_setup(
		&sb1,  // hook structure
		"Landroid/app/Activity;",  // class and package name (follow format!!! watch the >L<)
		// see http://docs.oracle.com/javase/1.5.0/docs/guide/jni/spec/types.html
		"onPause", // method name
		"()V", // method signature: (ARGUMENTS in L format)Return_value
		1, // paramter size = number of args + 1 (if method not static)
		sb1_onpause); // function to use for patch
	dalvik_hook(&d, &sb1);
}


// END --- change stuff ---

// START -- load class --- this will need to be adjusted ---

void* loadclass_alt(JNIEnv *env)
{
	//if(viewcalled==0) {
	    int i = dexstuff_loaddex(&d, "/data/local/tmp/classes.dex");
	    log("loaddex res = %x\n", i)

		// load specific class form .dex file
	    void *clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.CuriousDroid", i); // adding the CuriousDroid class
	    log("CuriousDroid class = 0x%x\n", clazz1)
		 
		 void *clazz2 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.ViewNode", i); // adding the CuriousDroid class
	    log("ViewNode class = 0x%x\n", clazz2)
		 
		 void *clazz3 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.ExecutionState", i); // adding the CuriousDroid class
	    log("ExecutionState class = 0x%x\n", clazz3)
		 
		 void *clazz4 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.ActivityContainer", i);
		 log("ActivityContainer class = 0x%x\n", clazz4)

		 clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.Interaction", i);
		 log("Interaction class = 0x%x\n", clazz1)

		 clazz1 = dexstuff_defineclass(&d, "edu.neu.ccs.curiousdroid.InteractionHandler", i);
		 log("InteractionHandler class = 0x%x\n", clazz1)
		 jthrowable exc = (*env)->ExceptionOccurred(env);
		 if(exc)
			 (*env)->ExceptionDescribe(env);
		 else
			log("First exception check ok.\n")
			
		 jclass cdroid = (*env)->FindClass(env, "edu/neu/ccs/curiousdroid/CuriousDroid");
	    log("cdroid: 0x%x\n", cdroid)
		 exc = (*env)->ExceptionOccurred(env);
		 if(exc)
			 (*env)->ExceptionDescribe(env);
		 else
			log("Second exception check ok.\n")
			
		 jclass vn = (*env)->FindClass(env, "edu/neu/ccs/curiousdroid/ViewNode");
	    log("vn: 0x%x\n", vn)
		 exc = (*env)->ExceptionOccurred(env);
		 if(exc)
			 (*env)->ExceptionDescribe(env);
		 else
			log("Third exception check ok.\n")
			
		 jmethodID vn_init = (*env)->GetMethodID(env, vn, "<init>", "(ILandroid/view/View;)V");
		 log("vn_init = 0x%x\n", vn_init)
		 // Just added this in.
		 jmethodID cdroid_init = (*env)->GetMethodID(env, cdroid, "<init>", "(Ledu/neu/ccs/curiousdroid/ViewNode;)V");
		 exc = (*env)->ExceptionOccurred(env);
		 if(exc)
			 (*env)->ExceptionDescribe(env);
		 else
			log("Fourth exception check ok.\n")
	 //}

	 jvalue margs[2];
	 //margs[0].i = 0;
	 margs[0].i = 0;
	 margs[1].l = seedview;
	 viewnodecls = (*env)->NewObjectA(env, vn, vn_init, margs);
	 log("viewnodecls = 0x%x\n", viewnodecls)
	 exc = (*env)->ExceptionOccurred(env);
	 if(exc)
		 (*env)->ExceptionDescribe(env);
	 else
		log("Fifth exception check ok.\n")
		
	 viewnodecls = (*env)->NewGlobalRef(env, viewnodecls);
	 log("viewnodecls = 0x%x\n", viewnodecls)
	 exc = (*env)->ExceptionOccurred(env);
	 if(exc)
		 (*env)->ExceptionDescribe(env);
	 else
		log("Sixth exception check ok.\n")
		
	 if(viewcalled == 0) {
		 cdroid_class = (*env)->NewObject(env, cdroid, cdroid_init, viewnodecls, NULL);
		 cdroid_class = (*env)->NewGlobalRef(env, cdroid_class);
		 exc = (*env)->ExceptionOccurred(env);
		 if(exc)
			 log("Couldn't generate CuriousDroid object.\n")
		 else
			 log("Just created CuriousDroid object\n")
		 
		 
	 }
	 else {
		 log("Previous instantiation of CuriousDroid object exists.  Using that. Method called %d times\n", viewcalled)
		 
	 }
	 
	 
    // get the method by name and signature
	 //;
	 //d.dvmDumpClass_fnPtr(d.dvmFindLoadedClass_fnPtr("Ledu/neu/ccs/curiousdroid/CuriousDroid;"), 1);
	 
    jmethodID jmid = (*env)->GetMethodID(env, cdroid, "expandChildViews", "(Ledu/neu/ccs/curiousdroid/ViewNode;I)V");
	 //jmethodID jmid2 = (*env)->
    log("jmid getID = 0x%x\n", jmid)
	 exc = (*env)->ExceptionOccurred(env);
	 if(exc)
		 (*env)->ExceptionDescribe(env);
	 else
		log("Seventh exception check ok.\n")
		
	 //cdroid = (*env)->NewGlobalRef(env, cdroid);
	 //jclass hashmap = (*env)->FindClass(env, "java/util/HashMap");
	 //jboolean isarrlist = (*env)->IsInstanceOf(env, viewlist, arrlist);
	 //log("hashmap = %d\n", hashmap)
		
	/* exc = (*env)->ExceptionOccurred(env);
	 if(exc)
		 (*env)->ExceptionDescribe(env);
	 else
		log("Eighth exception check ok.\n")*/
		
	 //jobject viewMap = (*env)->CallObjectMethod(env, cdroid_class, jmid, viewnodecls);
	 jvalue args[2];
	// args[0].l = NULL;
	 args[0].l = viewnodecls;
	 args[1].i = viewcalled;
	 (*env)->CallVoidMethodA(env, cdroid_class, jmid, args);
	 viewcalled++;
	 exc = (*env)->ExceptionOccurred(env);
	 if(exc) {
		 (*env)->ExceptionDescribe(env);
		 log("Failed trying to call expandChildViews from native side.\n")
	 } 
	 else
		log("Eighth exception check ok.\n")
	 /*viewMap = (*env)->NewGlobalRef(env, viewMap);
    log("viewMap = 0x%x\n", viewMap)
	 
	 exc = (*env)->ExceptionOccurred(env);
	 if(exc)
		 (*env)->ExceptionDescribe(env);
	 else
		log("Tenth exception check ok.\n")*/
	
	 /*//jmethodID jmid_print = (*env)->GetStaticMethodID(env, cdroid, "printViewMap", "(Ljava/util/HashMap;)V");
	 //(*env)->CallStaticVoidMethod(env, cdroid, jmid_print, viewMap);
	 exc = (*env)->ExceptionOccurred(env);
	 if(exc){
		 (*env)->ExceptionDescribe(env);
		 log("Error occured while calling printViewMap().\n")
	 }
	 else
		log("Eleventh exception check ok.\n")*/
	 
}




// END --- load class

// ---- don't need to modify ----

static int my_epoll_wait(int epfd, struct epoll_event *events, int maxevents, int timeout)
{
	int (*orig_epoll_wait)(int epfd, struct epoll_event *events, int maxevents, int timeout);

    orig_epoll_wait = (void*)eph.orig;

    hook_precall(&eph);

    dexstuff_resolv_dvm(&d);
	do_patch_onresume();
	//do_patch_onpause();
    int res = orig_epoll_wait(epfd, events, maxevents, timeout);
        
   return res;
}

void my_init(void)
{
	log("%s started\n", __FILE__)
 
 	// for libbase
	set_logfunction(my_log);
	// for libdalvikhook
	dalvikhook_set_logfunction(my_log);

    hook(&eph, getpid(), "libc.", "epoll_wait", my_epoll_wait, 0);
}