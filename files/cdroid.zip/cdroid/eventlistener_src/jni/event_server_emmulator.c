#include <netinet/in.h>    
#include <stdio.h>    
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <fcntl.h>
#include <poll.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/stat.h>    
#include <sys/types.h>    
#include <unistd.h>
#include <errno.h>


#undef log
#define log(...) \
        {FILE *fp = fopen("/data/local/tmp/log", "a+");\
        fprintf(fp, __VA_ARGS__);\
        fclose(fp);}

// from <linux/input.h>

struct input_event {
	struct timeval time;
	__u16 type;
	__u16 code;
	__s32 value;
};

#define EVIOCGVERSION		_IOR('E', 0x01, int)			/* get driver version */
#define EVIOCGID		_IOR('E', 0x02, struct input_id)	/* get device ID */
#define EVIOCGKEYCODE		_IOR('E', 0x04, int[2])			/* get keycode */
#define EVIOCSKEYCODE		_IOW('E', 0x04, int[2])			/* set keycode */

#define EVIOCGNAME(len)		_IOC(_IOC_READ, 'E', 0x06, len)		/* get device name */
#define EVIOCGPHYS(len)		_IOC(_IOC_READ, 'E', 0x07, len)		/* get physical location */
#define EVIOCGUNIQ(len)		_IOC(_IOC_READ, 'E', 0x08, len)		/* get unique identifier */

#define EVIOCGKEY(len)		_IOC(_IOC_READ, 'E', 0x18, len)		/* get global keystate */
#define EVIOCGLED(len)		_IOC(_IOC_READ, 'E', 0x19, len)		/* get all LEDs */
#define EVIOCGSND(len)		_IOC(_IOC_READ, 'E', 0x1a, len)		/* get all sounds status */
#define EVIOCGSW(len)		_IOC(_IOC_READ, 'E', 0x1b, len)		/* get all switch states */

#define EVIOCGBIT(ev,len)	_IOC(_IOC_READ, 'E', 0x20 + ev, len)	/* get event bits */
#define EVIOCGABS(abs)		_IOR('E', 0x40 + abs, struct input_absinfo)		/* get abs value/limits */
#define EVIOCSABS(abs)		_IOW('E', 0xc0 + abs, struct input_absinfo)		/* set abs value/limits */

#define EVIOCSFF		_IOC(_IOC_WRITE, 'E', 0x80, sizeof(struct ff_effect))	/* send a force effect to a force feedback device */
#define EVIOCRMFF		_IOW('E', 0x81, int)			/* Erase a force effect */
#define EVIOCGEFFECTS		_IOR('E', 0x84, int)			/* Report number of effects playable at the same time */

#define EVIOCGRAB		_IOW('E', 0x90, int)			/* Grab/Release device */

// end <linux/input.h>

#define BUFF_SIZE 65536
#define ARR_SIZE 65536
#define XMAX 400
#define YMAX 800
#define WAIT_TIME 20000

int main(int argc, char* argv[]) {
	char buffer[BUFF_SIZE];
	int event0fd,  perturbatorfd, readlen, t, version0, len, s, len2, timer, randcounter, file = 0;
	unsigned int sock1, sock2;
	struct sockaddr_un local, remote, remote0;
	struct pollfd ufds[1];
	srand(time(NULL));

	if((sock1 = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
		log("Couldn't create socket.\n")
		return 1;
	}
	log("Just created the socket.\n")

	local.sun_family = AF_UNIX;
	strcpy(local.sun_path, "/data/local/tmp/eventsocket");
	unlink(local.sun_path);
	len = strlen(local.sun_path) + sizeof(local.sun_family);
	if((bind(sock1, (struct sockaddr *)&local, len)) == -1) {
		log("Couldn't bind socket to local address.\n")
		return 2;
	}
	log("Just bound the socket\n")

	if(listen(sock1, 5) == -1) {
		log("Couldn't listen on socket.\n")
		return 3;
	}


	int done, n, ret, ret2, pollmsg;
	unsigned int t_off, type, code, value;
	int action[ARR_SIZE];
	int i, actionlen;
	//char* t_file;
	struct input_event event, eventpb;
	t = sizeof(remote);
	char* reset = "reset";

	if((sock2 = accept(sock1, (struct sockaddr *)&remote, &t)) == -1) {
		log("couldn't accept connection.\n" )
		return 5;
	}

	if((event0fd = open("/dev/input/event0", O_RDWR)) < 0) {
		log("Couldn't open event0 driver.\n")
		return 2;
	}
	log("Opened event0 driver.\n")

	if (ioctl(event0fd, EVIOCGVERSION, &version0) == -1) {
        log("could not get driver version for /dev/input/event0, %s\n", strerror(errno))
        return 1;
    }
    log("IO control on event0 driver.\n")

    log("assigning ufds\n")
	ufds[0].fd = sock2;
	ufds[0].events = POLLIN;
	randcounter = 0;
	int isRoot = 1;
	int waittime = WAIT_TIME;//20000;

	while(1) {
		
		pollmsg = poll(ufds, 1, waittime);
		//log("pollmsg = %d\n")
		if(pollmsg == -1) {
				// shit happened
			log("Something terrible happened during the poll() call!\n")
			break;
		}
		else if(pollmsg == 0) {
			//times up!  do something!
			waittime = 8000;//WAIT_TIME;
			log("times up!  time to perturbate the Activity.\n")
			if(randcounter == 0) {
				file = 0;
				actionlen = menuPress(&action[0]);
				randcounter++;
				log("Pressing Menu Button\n")
			}
			else if(randcounter < 7) {
				file = 1;
				actionlen = eventGenerator(&action[0], 10);
				randcounter++;
				log("Generating random interaction\n")
			}
			else {
				file = 2;
				randcounter = 0;
				actionlen = backPress(&action[0]);
				log("Presssing back button\n")
			}
			//log("just filled action.  received %d ints, action[0]= %d\n", actionlen, action[0])
			for(i = 0; (i+3) < actionlen; i+=4) {
				memset(&eventpb, 0, sizeof(eventpb));
			    eventpb.type = action[i+1];
			    eventpb.code = action[i+2];
			    eventpb.value = action[i+3];
			    usleep(action[i]);
			    ret = write(event0fd, &eventpb, sizeof(eventpb));
			    if(ret < sizeof(eventpb)) {
			    	log("Problem writing to event driver. File code = %d.\n", file)
			        //return -1;
			    }
			    //log("toffset: %d, event.type: %d, event.code: %d, event.value: %d\n", action[i], event.type, event.code, event.value)
			}
		}
		else {
			waittime = 8000;//WAIT_TIME;
			n = recv(sock2, buffer, BUFF_SIZE, 0);
			if(n > 0) {
				sleep(1);
				char* tmp;
				char* token = strtok(buffer, "\n");
				while(token != NULL) {
					if((tmp = strstr(token, "event0")) != NULL) {
						//log("event0 chosen\n")
						file = 0;
						token = strtok(NULL, "\n");
						continue;
					}
					sscanf(token, "%d %d %d %d", &t_off, &type, &code, &value);
					//log("t_off = %u, type = %u, code = %u, value = %u\n", t_off, type, code, value)
					
					memset(&event, 0, sizeof(event));
				    event.type = type;
				    event.code = code;
				    event.value = value;
				    usleep(t_off);
				    ret = write(event0fd, &event, sizeof(event));
				    if(ret < sizeof(eventpb)) {
			    		log("Problem writing to event driver from CurioisDroid generated instructions.\n")
			        	//return -1;
			    	}
				//    tot += ret;
					token = strtok(NULL, "\n");
				}
			}
		}
	}
}

int id = 0;
int initwait = 500000;
int eventGenerator(int* actions, int num) {
	//log("entered eventGenerator.  generating %d events.\n", num)
	int i, j, idx = 0, nidx;
	for(i = 0; i < num; i++) {
		int r = rand()%2;
		int output[4096];
		if(r == 0)
			nidx = swipe(&output[0]);
		else //(r == 1)
			nidx = buttonPress(&output[0]);
		//else
			//nidx = backPress(&output[0]);
		for(j = 0; j < nidx; j++)
			actions[idx+j] = output[j];
		idx += nidx;
	}
	//log("returning %d ints\n", idx)
	return idx;
}

int swipe(int* press) {
	//log("just entred swipe function\n")
	int sx = rand()%XMAX;
	int sy = 50 + rand()%(YMAX-100);
	int fx = rand()%XMAX;
	int fy = 50 + rand()%(YMAX-100);
	int dx = fx - sx;
	int dy = fy - sy;
	int t = 100000 + (rand() % 1000000);
	int dt, numupdates, xinc, yinc, i, j, counter;
	//int p32[32], p28[28];

	int p20[20] = {initwait, 3, 0, sx,
		115, 3, 1, sy,
		78, 0, 0, 0,
		60, 1, 330, 1,
		67243, 0, 0, 0};
	for(i=0;i<20;i++)
		press[i] = p20[i];

	if(abs(dx) > abs(dy)) {
		numupdates = abs(dx) / 16;
		dt = t / numupdates;
		xinc = (dx/abs(dx))*16;
		yinc = dy / numupdates;
	}
	else if(abs(dx) < abs(dy)) {
		numupdates = abs(dy) / 16;
		dt = t /numupdates;
		yinc = (dy/abs(dy))*16;
		xinc = dx / numupdates;
	}
	else {
		numupdates = abs(dx) / 16;
		yinc = (dy/abs(dy))*16;
		xinc = (dx/abs(dx))*16;
		dt = t/numupdates;
	}

	int p12[12] = {dt, 3, 0, 0, // used to end with sx+(i-31)*xinc
		115, 3, 1, 0,  // used to end with sy+(i-31)*yinc
		60, 0, 0, 0};
	counter = 20;
	for(i = 0; i < numupdates; i++) {
		p12[3] = sx+(xinc*(i+1));
		p12[7] = sy+(yinc*(i+1));
		for(j=0;j<12;j++) {
			press[counter++] = p12[j];
			//counter++;
		}
	}
	press[counter++] = 10000;
	press[counter++] = 1;
	press[counter++] = 330;
	press[counter++] = 0;
	press[counter++] = 75;
	press[counter++] = 0;
	press[counter++] = 0;
	press[counter++] = 0;
	//log("about to return %d ints from swipe\n", counter)
	return counter;
}

int buttonPress(int* press) {
	//log("just entered buttonPress\n")
	int x = rand()%XMAX;
	int y = 50 + rand()%(YMAX-50);
	int toffset = initwait + (rand() % 400000);
	int i;
	int tmp[24] = {toffset, 3, 0, x,
		115, 3, 1, y,
		78, 1, 330, 1,
		60, 0, 0, 0,
		67243, 1, 330, 0,
		130, 0, 0, 0};
	for(i=0;i<24;i++)
		press[i] = tmp[i];
	return 24;
}

int backPress(int* press) {
	//log("just entered backPress\n")
	int tmp[8] = {initwait, 1, 158, 1,
		65000, 1, 158, 0};
	int i;
	for(i=0;i<8;i++)
		press[i] = tmp[i];
	return 8;
}

int menuPress(int* press) {
	//log("just entered backPress\n")
	int tmp[8] = {initwait, 1, 229, 1,
		65000, 1, 229, 0};
	int i;
	for(i=0;i<8;i++)
		press[i] = tmp[i];
	return 8;
}
